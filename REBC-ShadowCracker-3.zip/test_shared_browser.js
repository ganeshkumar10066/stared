const SharedBrowserManager = require('./services/sharedBrowserManager');
const { playwrightPaymentRequest } = require('./services/playwrightPayment');
const { getProfileDataWithPlaywright } = require('./services/playwrightProfileScraper');
const browserMonitor = require('./services/browserMonitor');

async function testSharedBrowserManager() {
  console.log('=== Testing Shared Browser Manager ===\n');
  
  try {
    // Start monitoring
    browserMonitor.startMonitoring(10000); // Log every 10 seconds for testing
    
    // Test 1: Initialize browser manager
    console.log('1. Testing browser manager initialization...');
    const browserManager = SharedBrowserManager.getInstance();
    await browserManager.initialize();
    console.log('✓ Browser manager initialized successfully\n');
    
    // Test 2: Check initial status
    console.log('2. Checking initial status...');
    const status = browserManager.getStatus();
    console.log(`✓ Browsers: ${status.browsers}, Pages: ${status.pages}, Initialized: ${status.isInitialized}\n`);
    
    // Test 3: Test profile scraping
    console.log('3. Testing profile scraping...');
    const startTime = Date.now();
    const profileResult = await getProfileDataWithPlaywright('instagram');
    const profileTime = Date.now() - startTime;
    
    browserMonitor.recordRequest(!profileResult.error, profileTime);
    
    if (profileResult.error) {
      console.log(`⚠ Profile scraping result: ${profileResult.error}`);
    } else {
      console.log('✓ Profile scraping completed successfully');
    }
    console.log(`  Response time: ${profileTime}ms\n`);
    
    // Test 4: Test payment request (mock data)
    console.log('4. Testing payment request...');
    const mockPaymentData = {
      amount: '10.00',
      currency: 'USD',
      description: 'Test payment',
      timestamp: Date.now().toString()
    };
    
    const paymentStartTime = Date.now();
    const paymentResult = await playwrightPaymentRequest(mockPaymentData);
    const paymentTime = Date.now() - paymentStartTime;
    
    browserMonitor.recordRequest(!paymentResult.error, paymentTime);
    
    if (paymentResult.error) {
      console.log(`⚠ Payment request result: ${paymentResult.error}`);
    } else {
      console.log('✓ Payment request completed successfully');
    }
    console.log(`  Response time: ${paymentTime}ms\n`);
    
    // Test 5: Test concurrent requests
    console.log('5. Testing concurrent requests...');
    const concurrentPromises = [];
    
    for (let i = 0; i < 3; i++) {
      concurrentPromises.push(
        getProfileDataWithPlaywright(`testuser${i}`).then(result => {
          browserMonitor.recordRequest(!result.error, 0);
          return { index: i, result };
        })
      );
    }
    
    const concurrentResults = await Promise.allSettled(concurrentPromises);
    console.log(`✓ Concurrent requests completed: ${concurrentResults.length} total\n`);
    
    // Test 6: Check final status
    console.log('6. Checking final status...');
    const finalStatus = browserManager.getStatus();
    console.log(`✓ Final status - Browsers: ${finalStatus.browsers}, Pages: ${finalStatus.pages}`);
    console.log(`  Queue status: ${finalStatus.queues.map(q => `${q.queueSize}/${q.queuePending}`).join(', ')}\n`);
    
    // Test 7: Health check
    console.log('7. Running health check...');
    const healthResult = await browserMonitor.healthCheck();
    console.log(`✓ Health check result: ${healthResult ? 'PASSED' : 'FAILED'}\n`);
    
    // Test 8: Performance stats
    console.log('8. Performance statistics:');
    const stats = browserMonitor.getStats();
    console.log(`  Total requests: ${stats.totalRequests}`);
    console.log(`  Success rate: ${stats.totalRequests > 0 ? ((stats.successfulRequests / stats.totalRequests) * 100).toFixed(2) : 0}%`);
    console.log(`  Average response time: ${stats.averageResponseTime.toFixed(2)}ms`);
    console.log(`  Uptime: ${Math.floor(stats.uptime / 1000)}s\n`);
    
    console.log('=== All tests completed successfully! ===\n');
    
  } catch (error) {
    console.error('❌ Test failed:', error);
  } finally {
    // Stop monitoring
    browserMonitor.stopMonitoring();
    
    // Cleanup
    console.log('Cleaning up...');
    const browserManager = SharedBrowserManager.getInstance();
    await browserManager.cleanup();
    console.log('✓ Cleanup completed');
  }
}

// Run the test if this file is executed directly
if (require.main === module) {
  testSharedBrowserManager().catch(console.error);
}

module.exports = { testSharedBrowserManager };
