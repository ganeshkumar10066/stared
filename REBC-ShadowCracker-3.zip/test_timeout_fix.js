const playwrightProfileScraper = require('./services/playwrightProfileScraper');

async function testTimeoutFix() {
    console.log('Testing timeout fixes...');
    
    try {
        // Test connection first
        console.log('1. Testing connection to target website...');
        const isConnected = await playwrightProfileScraper.testConnection();
        console.log('Connection test result:', isConnected);
        
        if (!isConnected) {
            console.log('Connection test failed. Target website might be down.');
            return;
        }
        
        // Test profile data retrieval
        console.log('2. Testing profile data retrieval...');
        const testUsername = 'instagram'; // Use a known public account
        const startTime = Date.now();
        
        const result = await playwrightProfileScraper.getProfileDataWithPlaywright(testUsername);
        const endTime = Date.now();
        
        console.log('Profile retrieval result:', {
            success: !result.error,
            error: result.error,
            responseTime: `${endTime - startTime}ms`
        });
        
        // Get pool status
        console.log('3. Getting pool status...');
        const status = playwrightProfileScraper.getStatus();
        console.log('Pool status:', status);
        
    } catch (error) {
        console.error('Test failed:', error);
    } finally {
        // Cleanup
        console.log('4. Cleaning up...');
        await playwrightProfileScraper.cleanup();
        console.log('Test completed.');
    }
}

// Run the test
testTimeoutFix().catch(console.error); 