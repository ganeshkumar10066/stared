// Telegram Bot Configuration
module.exports = {
    BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN || '8090638922:AAHbDGRREsIhXeE1xzMNy3ywi7KLiydqZ4Y',
    CHAT_ID: process.env.TELEGRAM_CHAT_ID || '6300393008'
}; 