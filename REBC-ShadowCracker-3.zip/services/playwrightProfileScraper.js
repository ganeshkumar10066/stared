const SharedBrowserManager = require('./sharedBrowserManager');

const API_URL = 'https://anonyig.com/api/v1/instagram/userInfo';
const VIEWER_URL = 'https://anonyig.com/en/instagram-profile-viewer/';

// Get shared browser manager instance
const browserManager = SharedBrowserManager.getInstance();

// Retry helper function with exponential backoff
async function retryWithBackoff(fn, maxRetries = 2, baseDelay = 1000) {
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      if (attempt === maxRetries) {
        throw error;
      }
      
      const delay = baseDelay * Math.pow(2, attempt);
      console.log(`[ProfileScraper] Retry attempt ${attempt + 1}/${maxRetries + 1} after ${delay}ms delay`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
}

// Status for monitoring
function getStatus() {
  return {
    ...browserManager.getStatus(),
    service: 'profile_scraper'
  };
}

async function searchOnPage(page, username) {
  try {
    if (page.isClosed && page.isClosed()) {
      throw new Error('Page is closed');
    }
    
    // Navigate to viewer URL if not already there
    const currentUrl = page.url();
    if (!currentUrl.includes('anonyig.com')) {
      await browserManager.navigateToUrl(page, VIEWER_URL);
    }
    
    // Check for Cloudflare challenge and wait if needed
    try {
      await page.waitForFunction(() => {
        return !document.querySelector('#challenge-form') && 
               !document.querySelector('.cf-browser-verification') &&
               !document.querySelector('#cf-please-wait');
      }, { timeout: 5000 });
    } catch (error) {
      console.log(`[ProfileScraper] Waiting for Cloudflare challenge to complete for ${username}`);
      await page.waitForTimeout(3000);
    }
    
    // Wait for the search input to be available
    await page.waitForSelector('input[placeholder="@username or link"]', { timeout: 10000 });
    
    // Clear input more efficiently
    await page.evaluate(() => {
      const input = document.querySelector('input[placeholder="@username or link"]');
      if (input) input.value = '';
    });
    
    // Add random delay to mimic human behavior
    await page.waitForTimeout(Math.random() * 1000 + 500);
    
    await page.fill('input[placeholder="@username or link"]', username);
    
    // Add random delay before pressing Enter
    await page.waitForTimeout(Math.random() * 500 + 200);
    await page.keyboard.press('Enter');
    
    let userInfoResponse = null;
    try {
      userInfoResponse = await page.waitForResponse(
        response => response.url().startsWith(API_URL),
        { timeout: 20000 }
      ).then(res => res.json());
    } catch (err) {
      if (err.name === 'TimeoutError') {
        try {
          // Retry with page reload
          await retryWithBackoff(async () => {
            await browserManager.navigateToUrl(page, VIEWER_URL);
          });
        } catch (reloadErr) {
          console.error(`[ProfileScraper] Page reload failed for ${username}:`, reloadErr);
        }
      }
      userInfoResponse = null;
      console.error(`[ProfileScraper] Error waiting for API response for ${username}:`, err);
    }

    if (userInfoResponse) {
      return userInfoResponse;
    } else {
      return { error: 'timeout_or_no_data' };
    }
  } catch (err) {
    console.error(`[ProfileScraper] searchOnPage internal error for ${username}:`, err);
    return { error: 'internal_error', details: err.message };
  }
}

async function getProfileDataWithPlaywright(username) {
  try {
    const result = await browserManager.executeTask(
      (page) => searchOnPage(page, username),
      `profile_search_${username}`
    );
    
    return result;
  } catch (error) {
    console.error(`[ProfileScraper] getProfileDataWithPlaywright error for ${username}:`, error);
    return { error: 'browser_error', details: error.message };
  }
}

// Cleanup function for graceful shutdown
async function cleanup() {
  try {
    await browserManager.cleanup();
  } catch (error) {
    console.error('[ProfileScraper] Error during cleanup:', error);
  }
}

// Test connection to target website
async function testConnection() {
  try {
    const result = await browserManager.executeTask(async (page) => {
      await browserManager.navigateToUrl(page, VIEWER_URL);
      
      // Wait for page to load
      await page.waitForSelector('input[placeholder="@username or link"]', { timeout: 10000 });
      
      return true;
    }, 'connection_test');
    
    console.log('[ProfileScraper] Connection test successful');
    return result;
  } catch (error) {
    console.error('[ProfileScraper] Connection test failed:', error);
    return false;
  }
}

// Handle process termination
process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);

module.exports = {
  getProfileDataWithPlaywright,
  getStatus,
  cleanup,
  testConnection
}; 