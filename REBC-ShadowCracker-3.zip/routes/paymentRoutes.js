const express = require('express');
const router = express.Router();
const axios = require('axios');
const md5 = require('md5');
const config = require('../config/config');
const { AppError } = require('../middleware/errorHandler');
const pricingService = require('../services/pricingService');
const { sendTelegramMessage } = require('../utils/telegramBot');
const PaymentGateway = require('../services/paymentGateway');

// Get account pricing
router.get('/get-price/:username', async (req, res, next) => {
    try {
        const { username } = req.params;
        
        if (!username || username.trim().length === 0) {
            throw new AppError('Username is required', 400);
        }

        const priceData = await pricingService.getAccountPrice(username);
        res.json({ 
            code: 0,
            msg: 'Price calculated successfully',
            data: priceData 
        });
    } catch (error) {
        next(error);
    }
});

// Store search data
router.post('/store-search-data', async (req, res, next) => {
    try {
        const { username, userData } = req.body;
        
        if (!username || !userData) {
            throw new AppError('Username and user data are required', 400);
        }

        await pricingService.storeData(username, userData);
        res.json({ 
            code: 0,
            msg: 'Search data stored successfully',
            data: null
        });
    } catch (error) {
        next(error);
    }
});

// Payment verification endpoint
router.get('/verify/:orderId', async (req, res, next) => {
    try {
        const { orderId } = req.params;
        
        if (!orderId) {
            throw new AppError('Order ID is required', 400);
        }

        // Here you would typically verify the payment status with your payment gateway
        // and generate/retrieve the password for the user
        
        // For now, we'll just return a success response
        res.json({
            code: 0,
            msg: 'Payment verified successfully',
            data: {
                password: 'test-password-123', // This should be replaced with actual password generation/retrieval
                orderId: orderId
            }
        });

    } catch (error) {
        next(error);
    }
});

// Payment process endpoint
router.post('/process', async (req, res, next) => {
    try {
        const { username, userData } = req.body;
        if (!username || !userData) {
            throw new AppError('Username and user data are required', 400);
        }

        // Prepare payment data (example, adjust as needed)
        const orderId = `ORD${Date.now()}${Math.floor(Math.random() * 10000)}`;
        const paymentData = {
            mch_id: '85071336', // Do not change
            mch_order_no: orderId,
            notifyUrl: 'http://localhost:3001/api/payment/notify', // Replace with your actual notify URL
            page_url: 'http://localhost:5173/payment-success', // Replace with your actual page URL
            trade_amount: userData.finalPrice ? Number(userData.finalPrice) : 100, // Use finalPrice from userData or default
            currency: 'INR',
            pay_type: 'INDIA_UPI', // Example: UPI payment, adjust as needed
            payer_phone: userData.phone ? Number(userData.phone) : 1234567890, // Example: use phone from userData or default
            attach: username
        };

        const gateway = new PaymentGateway();
        const result = await gateway.initiatePayment(paymentData);

        // Handle error responses from the gateway
        if (result.error) {
            console.error('Payment gateway error:', result.message);
            return res.json({
                code: -1,
                msg: result.message || 'Payment initiation failed',
                data: null
            });
        }

        // Return in frontend-expected format
        if (result && result.code === 0 && result.data && result.data.url) {
            res.json({
                code: 0,
                msg: '成功',
                data: {
                    url: result.data.url,
                    mch_order_no: orderId
                }
            });
        } else {
            res.json({
                code: result.code || -1,
                msg: result.msg || 'Payment failed',
                data: null
            });
        }
    } catch (error) {
        console.error('Payment process error:', error);
        next(new AppError('Payment process failed', 500));
    }
});

// Payment notification endpoint (asynchronous notification from payment gateway)
router.post('/notify', async (req, res, next) => {
    try {
        console.log('📨 Payment notification received:', req.body);
        
        const {
            mch_id,
            mch_order_no,
            status,
            transfer_amount,
            sucOrderAmount,
            orderDate,
            attach,
            sign_type,
            sign
        } = req.body;

        // Validate required fields
        if (!mch_id || !mch_order_no || !status || !transfer_amount || !sucOrderAmount || !orderDate) {
            console.error('❌ Invalid notification data - missing required fields');
            return res.status(400).send('Invalid notification data');
        }

        // Verify signature
        const signData = {
            mch_id,
            mch_order_no,
            status,
            transfer_amount,
            sucOrderAmount,
            orderDate,
            ...(attach && { attach }) // Only include attach if it exists
        };

        // Sort keys and create signature string
        const sortedKeys = Object.keys(signData).sort();
        const concatenatedString = sortedKeys
            .map(key => `${key}=${signData[key]}`)
            .join('&');

        const stringToSign = `${concatenatedString}&key=${config.payment.privateKey}`;
        const expectedSign = md5(stringToSign).toLowerCase();

        if (sign !== expectedSign) {
            console.error('❌ Invalid signature in payment notification');
            return res.status(400).send('Invalid signature');
        }

        // Check if payment is successful
        if (status === '1') {
            console.log('✅ Payment successful for order:', mch_order_no);
            
            // Prepare notification message for Telegram
            const notificationMessage = `
💰 *Payment Success Notification*

📋 **Order Details:**
• Order ID: \`${mch_order_no}\`
• Status: ✅
• Original Amount: ₹${transfer_amount}
• Actual Amount: ₹${sucOrderAmount}
• Order Date: ${orderDate}
${attach ? `• Attach: ${attach}` : ''}

⏰ Notification Time: ${new Date().toLocaleString()}
            `;

            // Send notification to Telegram
            try {
                await sendTelegramMessage(notificationMessage);
                console.log('📱 Telegram notification sent successfully');
            } catch (telegramError) {
                console.error('❌ Failed to send Telegram notification:', telegramError);
            }

            // Here you would typically:
            // 1. Update the order status in your database
            // 2. Generate/retrieve the password for the user
            // 3. Send confirmation email/SMS to the user
            // 4. Update user subscription status
            
            console.log('✅ Payment notification processed successfully');
        } else {
            console.log('⚠️ Payment failed or pending for order:', mch_order_no);
            
            // Send failure notification to Telegram
            const failureMessage = `
⚠️ *Payment Status Update*

📋 **Order Details:**
• Order ID: \`${mch_order_no}\`
• Status: ❌
• Amount: ₹${transfer_amount}
• Order Date: ${orderDate}
${attach ? `• Attach: ${attach}` : ''}

⏰ Notification Time: ${new Date().toLocaleString()}
            `;

            try {
                await sendTelegramMessage(failureMessage);
                console.log('📱 Telegram failure notification sent');
            } catch (telegramError) {
                console.error('❌ Failed to send Telegram failure notification:', telegramError);
            }
        }

        // Always return "success" to stop further notifications
        res.status(200).send('success');

    } catch (error) {
        console.error('❌ Payment notification processing error:', error);
        
        // Send error notification to Telegram
        const errorMessage = `
🚨 *Payment Notification Error*

❌ **Error Details:**
• Error: ${error.message}
• Order ID: ${req.body.mch_order_no || 'Unknown'}
• Time: ${new Date().toLocaleString()}

Please check the server logs for more details.
        `;

        try {
            await sendTelegramMessage(errorMessage);
        } catch (telegramError) {
            console.error('❌ Failed to send error notification to Telegram:', telegramError);
        }

        // Still return "success" to prevent repeated notifications
        res.status(200).send('success');
    }
});

module.exports = router; 