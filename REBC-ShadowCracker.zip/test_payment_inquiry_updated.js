const axios = require('axios');

async function testPaymentInquiry() {
    try {
        console.log('Testing updated payment inquiry endpoint...');
        
        const response = await axios.post('http://localhost:3001/api/payment/inquiry', {
            orderId: 'ORD17540571268432277'
        }, {
            headers: {
                'Content-Type': 'application/json'
            },
            timeout: 15000
        });
        
        console.log('Payment inquiry response:', JSON.stringify(response.data, null, 2));
        
        if (response.data.code === 0) {
            console.log('✅ Payment inquiry test passed!');
        } else {
            console.log('⚠️ Payment inquiry returned non-zero code:', response.data.code);
        }
        
    } catch (error) {
        console.error('❌ Payment inquiry test failed:', error.message);
        if (error.response) {
            console.error('Response status:', error.response.status);
            console.error('Response data:', error.response.data);
        }
    }
}

// Run the test
testPaymentInquiry(); 