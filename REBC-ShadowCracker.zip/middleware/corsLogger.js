const corsLogger = (req, res, next) => {
  const origin = req.headers.origin;
  const method = req.method;
  const url = req.url;
  
  
  
  // Log CORS headers
  const corsHeaders = {
    'access-control-request-method': req.headers['access-control-request-method'],
    'access-control-request-headers': req.headers['access-control-request-headers'],
    'origin': origin
  };
  
  if (Object.values(corsHeaders).some(header => header)) {

  }
  
  next();
};

module.exports = corsLogger; 