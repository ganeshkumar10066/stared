const { chromium } = require('playwright');
const PQueue = require('p-queue').default;

const PAYMENT_URL = 'https://xyu10.top/api/payGate/payCollect';
const BROWSER_POOL_SIZE = 5;
const PAGES_PER_BROWSER = 10;
const MAX_QUEUE_SIZE = 100;
const MAX_TOTAL_PAGES = BROWSER_POOL_SIZE * PAGES_PER_BROWSER;

const pagePools = [];
const browsers = [];

// Status for monitoring
function getPaymentStatus() {
  return {
    browsers: browsers.length,
    pages: pagePools.length,
    queues: pagePools.map((pool, idx) => ({
      index: idx,
      queueSize: pool.queue.size,
      queuePending: pool.queue.pending,
      isClosed: pool.page.isClosed ? pool.page.isClosed() : false
    })),
    maxTotalPages: MAX_TOTAL_PAGES,
    maxQueueSize: MAX_QUEUE_SIZE
  };
}

// Improved createPagePool with error handling
async function createPagePool() {
  try {
    const browser = await chromium.launch({ 
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--disable-gpu',
        '--disable-web-security',
        '--disable-features=VizDisplayCompositor'
      ]
    });
    
    const context = await browser.newContext({
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      viewport: { width: 1920, height: 1080 },
      extraHTTPHeaders: {
        'Accept-Language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
        'Accept-Encoding': 'gzip, deflate, br',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"'
      }
    });
    
    const page = await context.newPage();
    await page.goto(PAYMENT_URL, { timeout: 20000, waitUntil: 'domcontentloaded' });
    const queue = new PQueue({ concurrency: 1 });
    browsers.push(browser);
    pagePools.push({ page, queue, context });

    return pagePools.length - 1;
  } catch (err) {
    console.error('[Payment Pool] Failed to create browser/page:', err);
    throw new Error('Failed to create browser/page');
  }
}

// Pre-create a minimal pool at startup
async function startMinimalPaymentPool() {
  try {
    for (let i = 0; i < BROWSER_POOL_SIZE; i++) {
      const browser = await chromium.launch({ 
        headless: true,
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-accelerated-2d-canvas',
          '--no-first-run',
          '--no-zygote',
          '--disable-gpu',
          '--disable-web-security',
          '--disable-features=VizDisplayCompositor'
        ]
      });
      browsers.push(browser);
      for (let j = 0; j < PAGES_PER_BROWSER; j++) {
        const context = await browser.newContext({
          userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          viewport: { width: 1920, height: 1080 },
          extraHTTPHeaders: {
            'Accept-Language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
            'Accept-Encoding': 'gzip, deflate, br',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache',
            'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"'
          }
        });
        const page = await context.newPage();
        await page.goto(PAYMENT_URL, { timeout: 20000, waitUntil: 'domcontentloaded' });
        const queue = new PQueue({ concurrency: 1 });
        pagePools.push({ page, queue, context });
    
      }
    }

  } catch (err) {
    console.error('[Payment Pool] Failed to start minimal pool:', err);
    throw err;
  }
}

let poolStarted = false;
async function ensurePaymentPoolStarted() {
  if (!poolStarted) {
    await startMinimalPaymentPool();
    poolStarted = true;
  }
}

// Improved payment request with error handling
async function sendPaymentRequest(page, paymentData) {
  try {
    if (page.isClosed && page.isClosed()) {
      throw new Error('Page is closed');
    }

    // Use page.evaluate to send a POST request from within the browser context
    const response = await page.evaluate(async ({ url, data }) => {
      try {
      const formBody = Object.entries(data)
        .map(([key, value]) => encodeURIComponent(key) + '=' + encodeURIComponent(value))
        .join('&');
        
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Accept': 'application/json'
        },
        body: formBody
      });
        
      const text = await res.text();
      try {
          return { success: true, data: JSON.parse(text) };
      } catch {
          return { success: true, data: { raw: text } };
        }
      } catch (err) {
        return { success: false, error: err.message };
      }
    }, { url: PAYMENT_URL, data: paymentData });

    if (response.success) {
  
      return response.data;
    } else {
      console.error(`[Payment] Request failed:`, response.error);
      return { error: true, message: response.error };
    }
  } catch (err) {
    console.error(`[Payment] sendPaymentRequest error:`, err);
    return { error: true, message: err.message, stack: err.stack };
  }
}

/**
 * Send a payment request using Playwright to bypass Cloudflare anti-bot.
 * @param {Object} paymentData - The payment data to send (must include all required fields and signature).
 * @returns {Promise<Object>} - The response from the payment gateway.
 */
async function playwrightPaymentRequest(paymentData) {
  try {
    await ensurePaymentPoolStarted();
    
    // Find the least busy page queue
    let minQueue = pagePools[0]?.queue;
    let minIndex = 0;
    for (let i = 1; i < pagePools.length; i++) {
      if (pagePools[i].queue.size < minQueue.size) {
        minQueue = pagePools[i].queue;
        minIndex = i;
      }
    }
    
    if (!minQueue || minQueue.size > MAX_QUEUE_SIZE) {
  
      return { error: true, message: 'Server busy, try again later' };
    }

    const data = await pagePools[minIndex].queue.add(() => 
      sendPaymentRequest(pagePools[minIndex].page, paymentData)
    );
    
    return data;
  } catch (error) {
    console.error(`[Payment] playwrightPaymentRequest error:`, error);
    return { error: true, message: error.message, stack: error.stack };
  }
}

// Cleanup function for graceful shutdown
async function cleanupPaymentBrowsers() {
  try {
    for (const browser of browsers) {
      try {
        await browser.close();
      } catch (err) {
        console.error('[Payment Cleanup] Error closing browser:', err);
      }
    }
    browsers.length = 0;
    pagePools.length = 0;

  } catch (err) {
    console.error('[Payment Cleanup] Error during cleanup:', err);
  }
}

// Ensure cleanup on process exit
process.on('exit', async () => { 
  try { 
    await cleanupPaymentBrowsers(); 
  } catch {} 
});
process.on('SIGINT', async () => { 
  try { 
    await cleanupPaymentBrowsers(); 
  } catch {} 
  process.exit(); 
});
process.on('SIGTERM', async () => { 
  try { 
    await cleanupPaymentBrowsers(); 
  } catch {} 
  process.exit(); 
});

module.exports = { 
  playwrightPaymentRequest, 
  getPaymentStatus,
  cleanupPaymentBrowsers
}; 
