const { chromium } = require('playwright');
const PQueue = require('p-queue').default;

const API_URL = 'https://anonyig.com/api/v1/instagram/userInfo';
const VIEWER_URL = 'https://anonyig.com/en/instagram-profile-viewer/';
const BROWSER_POOL_SIZE = 3; // Increased from 1
const PAGES_PER_BROWSER = 9; // Increased from 2
const MAX_QUEUE_SIZE = 500; // Increased from 300
const MAX_TOTAL_PAGES = BROWSER_POOL_SIZE * PAGES_PER_BROWSER;

// Performance optimizations
const BROWSER_OPTIONS = {
  headless: true,
  args: [
    '--no-sandbox',
    '--disable-setuid-sandbox',
    '--disable-dev-shm-usage',
    '--disable-accelerated-2d-canvas',
    '--no-first-run',
    '--no-zygote',
    '--disable-gpu',
    '--disable-background-timer-throttling',
    '--disable-backgrounding-occluded-windows',
    '--disable-renderer-backgrounding',
    '--disable-features=TranslateUI',
    '--disable-ipc-flooding-protection',
    '--memory-pressure-off',
    '--max_old_space_size=4096'
  ]
};

const CONTEXT_OPTIONS = {
  userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  viewport: { width: 1280, height: 720 },
  deviceScaleFactor: 1,
  isMobile: false,
  hasTouch: false,
  javaScriptEnabled: true,
  acceptDownloads: false,
  ignoreHTTPSErrors: true,
  extraHTTPHeaders: {
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache'
  }
};

const pagePools = [];
const browsers = [];

// Status for monitoring
function getStatus() {
  return {
    browsers: browsers.length,
    pages: pagePools.length,
    queues: pagePools.map((pool, idx) => ({
      index: idx,
      queueSize: pool.queue.size,
      queuePending: pool.queue.pending,
      isClosed: pool.page.isClosed ? pool.page.isClosed() : false
    })),
    maxTotalPages: MAX_TOTAL_PAGES,
    maxQueueSize: MAX_QUEUE_SIZE
  };
}

async function createPagePool() {
  const browser = await chromium.launch(BROWSER_OPTIONS);
  const context = await browser.newContext(CONTEXT_OPTIONS);
  
  // Optimize page performance
  const page = await context.newPage();
  
  // Block unnecessary resources for faster loading
  await page.route('**/*', (route) => {
    const resourceType = route.request().resourceType();
    if (['image', 'stylesheet', 'font', 'media'].includes(resourceType)) {
      route.abort();
    } else {
      route.continue();
    }
  });
  
  await page.goto(VIEWER_URL, { 
    timeout: 15000, // Reduced from 20000
    waitUntil: 'domcontentloaded' 
  });
  
  const queue = new PQueue({ 
    concurrency: 2, // Increased from 1
    timeout: 30000 
  });
  
  browsers.push(browser);
  pagePools.push({ page, queue, context });
  return pagePools.length - 1;
}

async function searchOnPage(page, username) {
  try {
    if (page.isClosed && page.isClosed()) {
      throw new Error('Page is closed');
    }
    
    // Clear input more efficiently
    await page.evaluate(() => {
      const input = document.querySelector('input[placeholder="@username or link"]');
      if (input) input.value = '';
    });
    
    await page.fill('input[placeholder="@username or link"]', username);
    await page.keyboard.press('Enter');
    
    let userInfoResponse = null;
    try {
      userInfoResponse = await page.waitForResponse(
        response => response.url().startsWith(API_URL),
        { timeout: 10000 } // Reduced from 15000
      ).then(res => res.json());
    } catch (err) {
      if (err.name === 'TimeoutError') {
        try {
          await page.reload({ 
            timeout: 15000, // Reduced from 20000
            waitUntil: 'domcontentloaded' 
          });
        } catch (reloadErr) {}
      }
      userInfoResponse = null;
      console.error(`[Playwright] Error waiting for API response for ${username}:`, err);
    }
    

    if (userInfoResponse) {
      return userInfoResponse;
    } else {
      return { error: 'timeout_or_no_data' };
    }
  } catch (err) {
    console.error(`[Playwright] searchOnPage internal error for ${username}:`, err);
    return { error: 'internal_error', details: err.message };
  }
}

async function startMinimalPool() {

  
  for (let i = 0; i < BROWSER_POOL_SIZE; i++) {
    const browser = await chromium.launch(BROWSER_OPTIONS);
    browsers.push(browser);
    
    for (let j = 0; j < PAGES_PER_BROWSER; j++) {
      const context = await browser.newContext(CONTEXT_OPTIONS);
      const page = await context.newPage();
      
      // Block unnecessary resources
      await page.route('**/*', (route) => {
        const resourceType = route.request().resourceType();
        if (['image', 'stylesheet', 'font', 'media'].includes(resourceType)) {
          route.abort();
        } else {
          route.continue();
        }
      });
      
      await page.goto(VIEWER_URL, { 
        timeout: 15000,
        waitUntil: 'domcontentloaded' 
      });
      
      const queue = new PQueue({ 
        concurrency: 2,
        timeout: 30000 
      });
      
      pagePools.push({ page, queue, context });
    }
  }
  

}

let poolStarted = false;
async function ensurePoolStarted() {
  if (!poolStarted) {
    await startMinimalPool();
    poolStarted = true;
  }
}

async function getProfileDataWithPlaywright(username) {
  await ensurePoolStarted();
  
  // Find the least busy page queue
  let selectedPool = pagePools[0];
  let minQueueSize = selectedPool.queue.size + selectedPool.queue.pending;
  
  for (const pool of pagePools) {
    const currentQueueSize = pool.queue.size + pool.queue.pending;
    if (currentQueueSize < minQueueSize) {
      minQueueSize = currentQueueSize;
      selectedPool = pool;
    }
  }
  
  return selectedPool.queue.add(async () => {
    try {
      const result = await searchOnPage(selectedPool.page, username);
      return result;
    } catch (error) {
      console.error(`[Playwright] Queue error for ${username}:`, error);
      throw error;
    }
  });
}

// Cleanup function for graceful shutdown
async function cleanup() {

  
  for (const pool of pagePools) {
    try {
      await pool.context.close();
    } catch (error) {
      console.error('[Playwright] Error closing context:', error);
    }
  }
  
  for (const browser of browsers) {
    try {
      await browser.close();
    } catch (error) {
      console.error('[Playwright] Error closing browser:', error);
    }
  }
  
  pagePools.length = 0;
  browsers.length = 0;
  poolStarted = false;
}

// Handle process termination
process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);

module.exports = {
  getProfileDataWithPlaywright,
  getStatus,
  cleanup
}; 