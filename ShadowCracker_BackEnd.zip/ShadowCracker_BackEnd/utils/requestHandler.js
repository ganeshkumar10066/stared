const axios = require('axios');
const { HttpsProxyAgent } = require('https-proxy-agent');
const { getNextProxy } = require('../config/proxies');
const { getHeaders } = require('../config/instagram');

async function makeRequest(url, options = {}) {
  const maxRetries = 3;
  let lastError;

  for (let i = 0; i < maxRetries; i++) {
    try {
      const proxy = await getNextProxy();
      
      // Skip proxy if none available
      if (!proxy) {
        console.log('No proxy available, making direct request...');
        const response = await axios({
          ...options,
          url,
          timeout: 15000,
          maxRedirects: 5,
          validateStatus: function (status) {
            return status >= 200 && status < 500;
          }
        });
        return response;
      }

      try {
        const agent = new HttpsProxyAgent(proxy);
        
        const response = await axios({
          ...options,
          url,
          httpsAgent: agent,
          proxy: false,
          timeout: 15000,
          maxRedirects: 5,
          validateStatus: function (status) {
            return status >= 200 && status < 500;
          }
        });

        if (response.status === 200) {
          return response;
        }

        if (response.status === 403 || response.status === 429) {
          console.log(`Proxy ${proxy} returned ${response.status}, trying next proxy...`);
          continue;
        }

        return response;
      } catch (proxyError) {
        console.error(`Error with proxy ${proxy}:`, proxyError.message);
        // If proxy fails, try direct request
        console.log('Attempting direct request after proxy failure...');
        const response = await axios({
          ...options,
          url,
          timeout: 15000,
          maxRedirects: 5,
          validateStatus: function (status) {
            return status >= 200 && status < 500;
          }
        });
        return response;
      }
    } catch (error) {
      lastError = error;
      console.log(`Attempt ${i + 1} failed: ${error.message}`);
      await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1)));
    }
  }

  throw lastError;
}

module.exports = {
  makeRequest
}; 