const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const connectDB = require('./config/db');
const profileRoutes = require('./routes/profile');
const imageRoutes = require('./routes/image');
const paymentRoutes = require('./routes/paymentRoutes');
const passwordRoutes = require('./routes/passwordRoutes');
const proxyRoutes = require('./routes/proxyRoutes');
const instagramCookieRoutes = require('./routes/instagramCookieRoutes');

const app = express();
const port = 3001;

// Connect to MongoDB
connectDB();

// Create public directory for default avatar
const publicDir = path.join(__dirname, 'public');

if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir);
}

// Create default avatar if it doesn't exist
const defaultAvatarPath = path.join(publicDir, 'default-avatar.png');
if (!fs.existsSync(defaultAvatarPath)) {
  // Create a simple default avatar (1x1 transparent pixel)
  const defaultAvatar = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=', 'base64');
  fs.writeFileSync(defaultAvatarPath, defaultAvatar);
}

// Enable CORS for all routes
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', '*');
  res.header('Access-Control-Allow-Credentials', 'true');
  
  // Handle preflight
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  next();
});

// Body parsing middleware
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Serve static files
app.use('/public', express.static(publicDir, {
  maxAge: '1d',
  etag: true,
  lastModified: true
}));

// Routes
app.use('/api/profile', profileRoutes);
app.use('/api/image', imageRoutes);
app.use('/api/payment', paymentRoutes);
app.use('/api/password', passwordRoutes);
app.use('/api/proxies', proxyRoutes);
app.use('/api/instagram-cookies', instagramCookieRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  
  // Add CORS headers to error responses
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', '*');
  res.header('Access-Control-Allow-Credentials', 'true');
  
  res.status(err.status || 500).json({
    code: -1,
    msg: err.message || 'Internal server error',
    data: null
  });
});

// Start server
app.listen(port, '0.0.0.0', () => {
  console.log(`Server running at http://0.0.0.0:${port}`);
}); 