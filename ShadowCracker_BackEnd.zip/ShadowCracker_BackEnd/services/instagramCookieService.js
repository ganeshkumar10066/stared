const InstagramCookie = require('../models/InstagramCookie');

class InstagramCookieService {
    // Add a new cookie
    async addCookie(cookieData) {
        try {
            const cookie = new InstagramCookie(cookieData);
            return await cookie.save();
        } catch (error) {
            throw new Error(`Error adding cookie: ${error.message}`);
        }
    }

    // Add multiple cookies
    async addMultipleCookies(cookiesData) {
        try {
            return await InstagramCookie.insertMany(cookiesData);
        } catch (error) {
            throw new Error(`Error adding multiple cookies: ${error.message}`);
        }
    }

    // Get all cookies
    async getAllCookies() {
        try {
            return await InstagramCookie.find();
        } catch (error) {
            throw new Error(`Error fetching cookies: ${error.message}`);
        }
    }

    // Get active cookies
    async getActiveCookies() {
        try {
            return await InstagramCookie.find({ 
                isActive: true,
                expiresAt: { $gt: new Date() }
            });
        } catch (error) {
            throw new Error(`Error fetching active cookies: ${error.message}`);
        }
    }

    // Get cookies by username
    async getCookiesByUsername(username) {
        try {
            return await InstagramCookie.find({ 
                username,
                isActive: true,
                expiresAt: { $gt: new Date() }
            });
        } catch (error) {
            throw new Error(`Error fetching cookies for username: ${error.message}`);
        }
    }

    // Get a cookie by ID
    async getCookieById(id) {
        try {
            return await InstagramCookie.findById(id);
        } catch (error) {
            throw new Error(`Error fetching cookie: ${error.message}`);
        }
    }

    // Update a cookie
    async updateCookie(id, updateData) {
        try {
            return await InstagramCookie.findByIdAndUpdate(
                id,
                { ...updateData, updatedAt: Date.now() },
                { new: true }
            );
        } catch (error) {
            throw new Error(`Error updating cookie: ${error.message}`);
        }
    }

    // Delete a cookie
    async deleteCookie(id) {
        try {
            return await InstagramCookie.findByIdAndDelete(id);
        } catch (error) {
            throw new Error(`Error deleting cookie: ${error.message}`);
        }
    }

    // Get a random active cookie
    async getRandomCookie() {
        try {
            const count = await InstagramCookie.countDocuments({ 
                isActive: true,
                expiresAt: { $gt: new Date() }
            });
            const random = Math.floor(Math.random() * count);
            const cookie = await InstagramCookie.findOne({ 
                isActive: true,
                expiresAt: { $gt: new Date() }
            }).skip(random);
            
            if (cookie) {
                cookie.lastUsed = Date.now();
                await cookie.save();
            }
            
            return cookie;
        } catch (error) {
            throw new Error(`Error getting random cookie: ${error.message}`);
        }
    }

    // Deactivate expired cookies
    async deactivateExpiredCookies() {
        try {
            return await InstagramCookie.updateMany(
                { 
                    expiresAt: { $lt: new Date() },
                    isActive: true
                },
                { 
                    $set: { isActive: false }
                }
            );
        } catch (error) {
            throw new Error(`Error deactivating expired cookies: ${error.message}`);
        }
    }
}

module.exports = new InstagramCookieService(); 