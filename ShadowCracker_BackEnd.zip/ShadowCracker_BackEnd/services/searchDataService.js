const axios = require('axios');

// Store search data
async function storeSearchData(username, userData) {
    try {
        await axios.post('http://13.49.21.2:3001/api/payment/store-search-data', {
            username,
            userData
        });
    } catch (error) {
        console.error('Error storing search data:', error);
        throw error;
    }
}

module.exports = {
    storeSearchData
}; 
