const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { requestLogger, errorLogger } = require('./middleware/logger');
const { errorHandler } = require('./middleware/errorHandler');
const { apiLimiter } = require('./middleware/rateLimiter');

// Initialize express app
const app = express();

// Create public directory if it doesn't exist
const publicDir = path.join(__dirname, '../public');
if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
}

// Create default avatar if it doesn't exist
const defaultAvatarPath = path.join(publicDir, 'default-avatar.png');
if (!fs.existsSync(defaultAvatarPath)) {
    // You would need to provide a default avatar image
    fs.copyFileSync(path.join(__dirname, 'assets/default-avatar.png'), defaultAvatarPath);
}

// Middleware
app.use(cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Apply rate limiting to all routes
app.use(apiLimiter);

// Request logging
app.use(requestLogger);

// Serve static files
app.use('/public', express.static(publicDir));

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/users', require('./routes/users'));
app.use('/api/profile', require('./routes/profile'));
app.use('/api/payment', require('./routes/payment'));

// Error logging
app.use(errorLogger);

// Error handling
app.use(errorHandler);

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        code: -1,
        msg: 'Route not found'
    });
});

module.exports = app; 