/**
 * Truncate string to specified length
 * @param {string} str - String to truncate
 * @param {number} length - Maximum length
 * @param {string} suffix - Suffix to add if truncated
 * @returns {string} Truncated string
 */
const truncate = (str, length = 100, suffix = '...') => {
    if (str.length <= length) return str;
    return str.substring(0, length - suffix.length) + suffix;
};

/**
 * Convert string to slug
 * @param {string} str - String to convert
 * @returns {string} Slug
 */
const toSlug = (str) => {
    return str
        .toLowerCase()
        .trim()
        .replace(/[^\w\s-]/g, '')
        .replace(/[\s_-]+/g, '-')
        .replace(/^-+|-+$/g, '');
};

/**
 * Convert string to title case
 * @param {string} str - String to convert
 * @returns {string} Title case string
 */
const toTitleCase = (str) => {
    return str.replace(
        /\w\S*/g,
        (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
    );
};

/**
 * Generate random string
 * @param {number} length - Length of string
 * @returns {string} Random string
 */
const generateRandomString = (length = 8) => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
};

/**
 * Mask string (e.g., for credit card numbers)
 * @param {string} str - String to mask
 * @param {number} start - Start position
 * @param {number} end - End position
 * @param {string} mask - Mask character
 * @returns {string} Masked string
 */
const maskString = (str, start = 0, end = str.length, mask = '*') => {
    if (start >= end) return str;
    return str.substring(0, start) + mask.repeat(end - start) + str.substring(end);
};

/**
 * Format number with commas
 * @param {number} num - Number to format
 * @returns {string} Formatted number
 */
const formatNumber = (num) => {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
};

/**
 * Convert string to camel case
 * @param {string} str - String to convert
 * @returns {string} Camel case string
 */
const toCamelCase = (str) => {
    return str
        .replace(/(?:^\w|[A-Z]|\b\w)/g, (word, index) => {
            return index === 0 ? word.toLowerCase() : word.toUpperCase();
        })
        .replace(/\s+/g, '');
};

/**
 * Convert string to snake case
 * @param {string} str - String to convert
 * @returns {string} Snake case string
 */
const toSnakeCase = (str) => {
    return str
        .replace(/\W+/g, ' ')
        .split(/ |\B(?=[A-Z])/)
        .map(word => word.toLowerCase())
        .join('_');
};

/**
 * Convert string to kebab case
 * @param {string} str - String to convert
 * @returns {string} Kebab case string
 */
const toKebabCase = (str) => {
    return str
        .replace(/\W+/g, ' ')
        .split(/ |\B(?=[A-Z])/)
        .map(word => word.toLowerCase())
        .join('-');
};

module.exports = {
    truncate,
    toSlug,
    toTitleCase,
    generateRandomString,
    maskString,
    formatNumber,
    toCamelCase,
    toSnakeCase,
    toKebabCase
}; 