/**
 * Chunk array into smaller arrays
 * @param {Array} array - Array to chunk
 * @param {number} size - Size of each chunk
 * @returns {Array} Chunked array
 */
const chunk = (array, size) => {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
        chunks.push(array.slice(i, i + size));
    }
    return chunks;
};

/**
 * Remove duplicates from array
 * @param {Array} array - Array to remove duplicates from
 * @returns {Array} Array without duplicates
 */
const unique = (array) => {
    return [...new Set(array)];
};

/**
 * Shuffle array
 * @param {Array} array - Array to shuffle
 * @returns {Array} Shuffled array
 */
const shuffle = (array) => {
    const result = [...array];
    for (let i = result.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
};

/**
 * Get random item from array
 * @param {Array} array - Array to get random item from
 * @returns {*} Random item
 */
const random = (array) => {
    return array[Math.floor(Math.random() * array.length)];
};

/**
 * Get random items from array
 * @param {Array} array - Array to get random items from
 * @param {number} count - Number of items to get
 * @returns {Array} Random items
 */
const randomItems = (array, count) => {
    return shuffle(array).slice(0, count);
};

/**
 * Group array by key
 * @param {Array} array - Array to group
 * @param {string} key - Key to group by
 * @returns {Object} Grouped array
 */
const groupBy = (array, key) => {
    return array.reduce((result, item) => {
        const group = item[key];
        result[group] = result[group] || [];
        result[group].push(item);
        return result;
    }, {});
};

/**
 * Sort array by key
 * @param {Array} array - Array to sort
 * @param {string} key - Key to sort by
 * @param {string} order - Sort order ('asc' or 'desc')
 * @returns {Array} Sorted array
 */
const sortBy = (array, key, order = 'asc') => {
    return [...array].sort((a, b) => {
        const aValue = a[key];
        const bValue = b[key];
        if (order === 'desc') {
            return bValue > aValue ? 1 : -1;
        }
        return aValue > bValue ? 1 : -1;
    });
};

/**
 * Flatten nested array
 * @param {Array} array - Array to flatten
 * @returns {Array} Flattened array
 */
const flatten = (array) => {
    return array.reduce((result, item) => {
        return result.concat(Array.isArray(item) ? flatten(item) : item);
    }, []);
};

/**
 * Get intersection of arrays
 * @param {...Array} arrays - Arrays to get intersection of
 * @returns {Array} Intersection of arrays
 */
const intersection = (...arrays) => {
    return arrays.reduce((result, array) => {
        return result.filter(item => array.includes(item));
    });
};

/**
 * Get union of arrays
 * @param {...Array} arrays - Arrays to get union of
 * @returns {Array} Union of arrays
 */
const union = (...arrays) => {
    return unique(flatten(arrays));
};

module.exports = {
    chunk,
    unique,
    shuffle,
    random,
    randomItems,
    groupBy,
    sortBy,
    flatten,
    intersection,
    union
}; 