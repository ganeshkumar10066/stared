/**
 * Get nested object property
 * @param {Object} obj - Object to get property from
 * @param {string} path - Path to property
 * @param {*} defaultValue - Default value if property doesn't exist
 * @returns {*} Property value
 */
const get = (obj, path, defaultValue = undefined) => {
    const travel = regexp =>
        String.prototype.split
            .call(path, regexp)
            .filter(Boolean)
            .reduce((res, key) => (res !== null && res !== undefined ? res[key] : res), obj);
    const result = travel(/[,[\]]+?/) || travel(/[,[\].]+?/);
    return result === undefined || result === obj ? defaultValue : result;
};

/**
 * Set nested object property
 * @param {Object} obj - Object to set property on
 * @param {string} path - Path to property
 * @param {*} value - Value to set
 * @returns {Object} Modified object
 */
const set = (obj, path, value) => {
    const keys = path.split('.');
    const lastKey = keys.pop();
    const lastObj = keys.reduce((obj, key) => {
        if (!(key in obj)) obj[key] = {};
        return obj[key];
    }, obj);
    lastObj[lastKey] = value;
    return obj;
};

/**
 * Pick properties from object
 * @param {Object} obj - Object to pick properties from
 * @param {Array} keys - Keys to pick
 * @returns {Object} Object with picked properties
 */
const pick = (obj, keys) => {
    return keys.reduce((result, key) => {
        if (key in obj) {
            result[key] = obj[key];
        }
        return result;
    }, {});
};

/**
 * Omit properties from object
 * @param {Object} obj - Object to omit properties from
 * @param {Array} keys - Keys to omit
 * @returns {Object} Object without omitted properties
 */
const omit = (obj, keys) => {
    return Object.keys(obj)
        .filter(key => !keys.includes(key))
        .reduce((result, key) => {
            result[key] = obj[key];
            return result;
        }, {});
};

/**
 * Deep merge objects
 * @param {...Object} objects - Objects to merge
 * @returns {Object} Merged object
 */
const deepMerge = (...objects) => {
    return objects.reduce((result, obj) => {
        Object.keys(obj).forEach(key => {
            if (typeof obj[key] === 'object' && obj[key] !== null) {
                result[key] = deepMerge(result[key] || {}, obj[key]);
            } else {
                result[key] = obj[key];
            }
        });
        return result;
    }, {});
};

/**
 * Deep clone object
 * @param {Object} obj - Object to clone
 * @returns {Object} Cloned object
 */
const deepClone = (obj) => {
    if (obj === null || typeof obj !== 'object') {
        return obj;
    }
    if (obj instanceof Date) {
        return new Date(obj);
    }
    if (obj instanceof Array) {
        return obj.map(item => deepClone(item));
    }
    if (obj instanceof Object) {
        return Object.keys(obj).reduce((result, key) => {
            result[key] = deepClone(obj[key]);
            return result;
        }, {});
    }
};

/**
 * Flatten nested object
 * @param {Object} obj - Object to flatten
 * @param {string} prefix - Prefix for keys
 * @returns {Object} Flattened object
 */
const flatten = (obj, prefix = '') => {
    return Object.keys(obj).reduce((result, key) => {
        const pre = prefix.length ? `${prefix}.` : '';
        if (typeof obj[key] === 'object' && obj[key] !== null) {
            Object.assign(result, flatten(obj[key], pre + key));
        } else {
            result[pre + key] = obj[key];
        }
        return result;
    }, {});
};

/**
 * Invert object keys and values
 * @param {Object} obj - Object to invert
 * @returns {Object} Inverted object
 */
const invert = (obj) => {
    return Object.keys(obj).reduce((result, key) => {
        result[obj[key]] = key;
        return result;
    }, {});
};

/**
 * Map object values
 * @param {Object} obj - Object to map
 * @param {Function} fn - Function to map values
 * @returns {Object} Mapped object
 */
const mapValues = (obj, fn) => {
    return Object.keys(obj).reduce((result, key) => {
        result[key] = fn(obj[key], key, obj);
        return result;
    }, {});
};

module.exports = {
    get,
    set,
    pick,
    omit,
    deepMerge,
    deepClone,
    flatten,
    invert,
    mapValues
}; 