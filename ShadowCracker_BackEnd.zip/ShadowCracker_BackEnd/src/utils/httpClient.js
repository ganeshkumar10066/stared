const axios = require('axios');
const { logger } = require('../middleware/logger');
const AppError = require('./AppError');

// Create axios instance with default config
const httpClient = axios.create({
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json'
    }
});

// Add request interceptor
httpClient.interceptors.request.use(
    config => {
        // Log request
        logger.debug('HTTP Request:', {
            method: config.method,
            url: config.url,
            headers: config.headers,
            data: config.data
        });
        return config;
    },
    error => {
        logger.error('HTTP Request Error:', error);
        return Promise.reject(error);
    }
);

// Add response interceptor
httpClient.interceptors.response.use(
    response => {
        // Log response
        logger.debug('HTTP Response:', {
            status: response.status,
            headers: response.headers,
            data: response.data
        });
        return response;
    },
    error => {
        // Log error
        logger.error('HTTP Response Error:', {
            status: error.response?.status,
            data: error.response?.data,
            message: error.message
        });

        // Handle different types of errors
        if (error.response) {
            // Server responded with error
            throw new AppError(
                error.response.data?.message || 'Server error',
                error.response.status
            );
        } else if (error.request) {
            // Request made but no response
            throw new AppError('No response from server', 503);
        } else {
            // Request setup error
            throw new AppError('Request failed', 500);
        }
    }
);

/**
 * Make GET request
 * @param {string} url - Request URL
 * @param {Object} config - Request config
 * @returns {Promise} Response promise
 */
const get = async (url, config = {}) => {
    try {
        const response = await httpClient.get(url, config);
        return response.data;
    } catch (error) {
        throw error;
    }
};

/**
 * Make POST request
 * @param {string} url - Request URL
 * @param {Object} data - Request data
 * @param {Object} config - Request config
 * @returns {Promise} Response promise
 */
const post = async (url, data = {}, config = {}) => {
    try {
        const response = await httpClient.post(url, data, config);
        return response.data;
    } catch (error) {
        throw error;
    }
};

/**
 * Make PUT request
 * @param {string} url - Request URL
 * @param {Object} data - Request data
 * @param {Object} config - Request config
 * @returns {Promise} Response promise
 */
const put = async (url, data = {}, config = {}) => {
    try {
        const response = await httpClient.put(url, data, config);
        return response.data;
    } catch (error) {
        throw error;
    }
};

/**
 * Make PATCH request
 * @param {string} url - Request URL
 * @param {Object} data - Request data
 * @param {Object} config - Request config
 * @returns {Promise} Response promise
 */
const patch = async (url, data = {}, config = {}) => {
    try {
        const response = await httpClient.patch(url, data, config);
        return response.data;
    } catch (error) {
        throw error;
    }
};

/**
 * Make DELETE request
 * @param {string} url - Request URL
 * @param {Object} config - Request config
 * @returns {Promise} Response promise
 */
const del = async (url, config = {}) => {
    try {
        const response = await httpClient.delete(url, config);
        return response.data;
    } catch (error) {
        throw error;
    }
};

/**
 * Make request with retry
 * @param {Function} requestFn - Request function
 * @param {number} maxRetries - Maximum number of retries
 * @param {number} delay - Delay between retries in milliseconds
 * @returns {Promise} Response promise
 */
const withRetry = async (requestFn, maxRetries = 3, delay = 1000) => {
    let lastError;
    
    for (let i = 0; i < maxRetries; i++) {
        try {
            return await requestFn();
        } catch (error) {
            lastError = error;
            if (i < maxRetries - 1) {
                await new Promise(resolve => setTimeout(resolve, delay * (i + 1)));
            }
        }
    }
    
    throw lastError;
};

module.exports = {
    httpClient,
    get,
    post,
    put,
    patch,
    del,
    withRetry
}; 