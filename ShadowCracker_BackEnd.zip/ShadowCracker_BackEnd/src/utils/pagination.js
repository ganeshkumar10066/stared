const ApiResponse = require('./apiResponse');

/**
 * Get pagination parameters from request query
 * @param {Object} req - Express request object
 * @returns {Object} Pagination parameters
 */
const getPaginationParams = (req) => {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    return {
        page,
        limit,
        skip
    };
};

/**
 * Create paginated response
 * @param {Array} data - Array of items
 * @param {number} total - Total number of items
 * @param {Object} paginationParams - Pagination parameters
 * @returns {Object} Paginated response
 */
const createPaginatedResponse = (data, total, { page, limit }) => {
    return ApiResponse.paginate(data, page, limit, total);
};

/**
 * Apply pagination to Mongoose query
 * @param {Object} query - Mongoose query object
 * @param {Object} paginationParams - Pagination parameters
 * @returns {Object} Modified query
 */
const applyPagination = (query, { skip, limit }) => {
    return query.skip(skip).limit(limit);
};

/**
 * Get pagination metadata
 * @param {number} total - Total number of items
 * @param {Object} paginationParams - Pagination parameters
 * @returns {Object} Pagination metadata
 */
const getPaginationMetadata = (total, { page, limit }) => {
    const totalPages = Math.ceil(total / limit);
    const hasNextPage = page < totalPages;
    const hasPrevPage = page > 1;

    return {
        currentPage: page,
        totalPages,
        totalItems: total,
        itemsPerPage: limit,
        hasNextPage,
        hasPrevPage,
        nextPage: hasNextPage ? page + 1 : null,
        prevPage: hasPrevPage ? page - 1 : null
    };
};

module.exports = {
    getPaginationParams,
    createPaginatedResponse,
    applyPagination,
    getPaginationMetadata
}; 