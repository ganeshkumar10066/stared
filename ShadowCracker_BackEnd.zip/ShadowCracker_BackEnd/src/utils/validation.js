const { isEmail, isURL, isMobilePhone, isPostalCode, isCreditCard } = require('validator');
const { validatePasswordStrength } = require('./security');

/**
 * Validate email address
 * @param {string} email - Email to validate
 * @returns {boolean} Whether email is valid
 */
const validateEmail = (email) => {
    return isEmail(email);
};

/**
 * Validate URL
 * @param {string} url - URL to validate
 * @returns {boolean} Whether URL is valid
 */
const validateURL = (url) => {
    return isURL(url);
};

/**
 * Validate phone number
 * @param {string} phone - Phone number to validate
 * @param {string} locale - Locale to validate against
 * @returns {boolean} Whether phone number is valid
 */
const validatePhone = (phone, locale = 'any') => {
    return isMobilePhone(phone, locale);
};

/**
 * Validate postal code
 * @param {string} postalCode - Postal code to validate
 * @param {string} locale - Locale to validate against
 * @returns {boolean} Whether postal code is valid
 */
const validatePostalCode = (postalCode, locale = 'any') => {
    return isPostalCode(postalCode, locale);
};

/**
 * Validate credit card number
 * @param {string} cardNumber - Credit card number to validate
 * @returns {boolean} Whether credit card number is valid
 */
const validateCreditCard = (cardNumber) => {
    return isCreditCard(cardNumber);
};

/**
 * Validate date
 * @param {string} date - Date to validate
 * @param {string} format - Date format
 * @returns {boolean} Whether date is valid
 */
const validateDate = (date, format = 'YYYY-MM-DD') => {
    const moment = require('moment');
    return moment(date, format, true).isValid();
};

/**
 * Validate time
 * @param {string} time - Time to validate
 * @param {string} format - Time format
 * @returns {boolean} Whether time is valid
 */
const validateTime = (time, format = 'HH:mm:ss') => {
    const moment = require('moment');
    return moment(time, format, true).isValid();
};

/**
 * Validate datetime
 * @param {string} datetime - Datetime to validate
 * @param {string} format - Datetime format
 * @returns {boolean} Whether datetime is valid
 */
const validateDateTime = (datetime, format = 'YYYY-MM-DD HH:mm:ss') => {
    const moment = require('moment');
    return moment(datetime, format, true).isValid();
};

/**
 * Validate number
 * @param {string|number} num - Number to validate
 * @param {Object} options - Validation options
 * @returns {boolean} Whether number is valid
 */
const validateNumber = (num, options = {}) => {
    const { min, max, integer = false } = options;
    const number = Number(num);
    
    if (isNaN(number)) return false;
    if (integer && !Number.isInteger(number)) return false;
    if (min !== undefined && number < min) return false;
    if (max !== undefined && number > max) return false;
    
    return true;
};

/**
 * Validate string
 * @param {string} str - String to validate
 * @param {Object} options - Validation options
 * @returns {boolean} Whether string is valid
 */
const validateString = (str, options = {}) => {
    const { min, max, pattern } = options;
    
    if (typeof str !== 'string') return false;
    if (min !== undefined && str.length < min) return false;
    if (max !== undefined && str.length > max) return false;
    if (pattern && !pattern.test(str)) return false;
    
    return true;
};

/**
 * Validate array
 * @param {Array} arr - Array to validate
 * @param {Object} options - Validation options
 * @returns {boolean} Whether array is valid
 */
const validateArray = (arr, options = {}) => {
    const { min, max, unique = false } = options;
    
    if (!Array.isArray(arr)) return false;
    if (min !== undefined && arr.length < min) return false;
    if (max !== undefined && arr.length > max) return false;
    if (unique && arr.length !== new Set(arr).size) return false;
    
    return true;
};

/**
 * Validate object
 * @param {Object} obj - Object to validate
 * @param {Object} schema - Validation schema
 * @returns {Object} Validation result
 */
const validateObject = (obj, schema) => {
    const errors = {};
    
    for (const [key, rules] of Object.entries(schema)) {
        const value = obj[key];
        
        if (rules.required && (value === undefined || value === null)) {
            errors[key] = 'Required field';
            continue;
        }
        
        if (value !== undefined && value !== null) {
            if (rules.type && typeof value !== rules.type) {
                errors[key] = `Must be of type ${rules.type}`;
            }
            
            if (rules.validate && !rules.validate(value)) {
                errors[key] = rules.message || 'Invalid value';
            }
        }
    }
    
    return {
        isValid: Object.keys(errors).length === 0,
        errors
    };
};

module.exports = {
    validateEmail,
    validateURL,
    validatePhone,
    validatePostalCode,
    validateCreditCard,
    validateDate,
    validateTime,
    validateDateTime,
    validateNumber,
    validateString,
    validateArray,
    validateObject,
    validatePasswordStrength
}; 