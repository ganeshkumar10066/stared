const fs = require('fs').promises;
const path = require('path');
const sharp = require('sharp');
const config = require('../config/config');
const AppError = require('./AppError');

/**
 * Create directory if it doesn't exist
 * @param {string} dirPath - Directory path
 */
const ensureDirectoryExists = async (dirPath) => {
    try {
        await fs.access(dirPath);
    } catch {
        await fs.mkdir(dirPath, { recursive: true });
    }
};

/**
 * Delete file if it exists
 * @param {string} filePath - File path
 */
const deleteFileIfExists = async (filePath) => {
    try {
        await fs.access(filePath);
        await fs.unlink(filePath);
    } catch {
        // File doesn't exist, ignore
    }
};

/**
 * Process and save image
 * @param {Buffer} buffer - Image buffer
 * @param {string} filename - Original filename
 * @param {Object} options - Processing options
 * @returns {string} Saved file path
 */
const processAndSaveImage = async (buffer, filename, options = {}) => {
    const {
        width = 800,
        height = 800,
        quality = 80,
        format = 'jpeg'
    } = options;

    const uploadDir = path.join(__dirname, '../../public/uploads');
    await ensureDirectoryExists(uploadDir);

    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const processedFilename = `${path.parse(filename).name}-${uniqueSuffix}.${format}`;
    const outputPath = path.join(uploadDir, processedFilename);

    try {
        await sharp(buffer)
            .resize(width, height, {
                fit: 'inside',
                withoutEnlargement: true
            })
            .toFormat(format, { quality })
            .toFile(outputPath);

        return `/uploads/${processedFilename}`;
    } catch (error) {
        throw new AppError('Error processing image', 500);
    }
};

/**
 * Get file size in human-readable format
 * @param {number} bytes - File size in bytes
 * @returns {string} Human-readable file size
 */
const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

/**
 * Validate file type
 * @param {string} mimetype - File MIME type
 * @returns {boolean} Whether file type is allowed
 */
const isValidFileType = (mimetype) => {
    return config.allowedFileTypes.includes(mimetype);
};

/**
 * Validate file size
 * @param {number} size - File size in bytes
 * @returns {boolean} Whether file size is allowed
 */
const isValidFileSize = (size) => {
    return size <= config.maxFileSize;
};

module.exports = {
    ensureDirectoryExists,
    deleteFileIfExists,
    processAndSaveImage,
    formatFileSize,
    isValidFileType,
    isValidFileSize
}; 