const moment = require('moment');

/**
 * Format date to ISO string
 * @param {Date|string} date - Date to format
 * @returns {string} Formatted date
 */
const formatDate = (date) => {
    return moment(date).toISOString();
};

/**
 * Format date to human-readable string
 * @param {Date|string} date - Date to format
 * @param {string} format - Format string
 * @returns {string} Formatted date
 */
const formatDateHuman = (date, format = 'MMMM Do YYYY, h:mm:ss a') => {
    return moment(date).format(format);
};

/**
 * Get relative time
 * @param {Date|string} date - Date to format
 * @returns {string} Relative time
 */
const getRelativeTime = (date) => {
    return moment(date).fromNow();
};

/**
 * Check if date is valid
 * @param {string} date - Date to check
 * @returns {boolean} Whether date is valid
 */
const isValidDate = (date) => {
    return moment(date).isValid();
};

/**
 * Get start and end of day
 * @param {Date|string} date - Date to get range for
 * @returns {Object} Start and end of day
 */
const getDayRange = (date) => {
    return {
        start: moment(date).startOf('day').toDate(),
        end: moment(date).endOf('day').toDate()
    };
};

/**
 * Get start and end of week
 * @param {Date|string} date - Date to get range for
 * @returns {Object} Start and end of week
 */
const getWeekRange = (date) => {
    return {
        start: moment(date).startOf('week').toDate(),
        end: moment(date).endOf('week').toDate()
    };
};

/**
 * Get start and end of month
 * @param {Date|string} date - Date to get range for
 * @returns {Object} Start and end of month
 */
const getMonthRange = (date) => {
    return {
        start: moment(date).startOf('month').toDate(),
        end: moment(date).endOf('month').toDate()
    };
};

/**
 * Add time to date
 * @param {Date|string} date - Date to add time to
 * @param {number} amount - Amount to add
 * @param {string} unit - Unit of time
 * @returns {Date} New date
 */
const addTime = (date, amount, unit) => {
    return moment(date).add(amount, unit).toDate();
};

/**
 * Subtract time from date
 * @param {Date|string} date - Date to subtract time from
 * @param {number} amount - Amount to subtract
 * @param {string} unit - Unit of time
 * @returns {Date} New date
 */
const subtractTime = (date, amount, unit) => {
    return moment(date).subtract(amount, unit).toDate();
};

/**
 * Get difference between dates
 * @param {Date|string} date1 - First date
 * @param {Date|string} date2 - Second date
 * @param {string} unit - Unit of time
 * @returns {number} Difference
 */
const getDateDifference = (date1, date2, unit = 'days') => {
    return moment(date1).diff(moment(date2), unit);
};

module.exports = {
    formatDate,
    formatDateHuman,
    getRelativeTime,
    isValidDate,
    getDayRange,
    getWeekRange,
    getMonthRange,
    addTime,
    subtractTime,
    getDateDifference
}; 