const nodemailer = require('nodemailer');
const config = require('../config/config');
const { logger } = require('../middleware/logger');
const AppError = require('./AppError');

// Create transporter
const transporter = nodemailer.createTransport({
    host: config.smtpHost,
    port: config.smtpPort,
    secure: config.smtpPort === 465,
    auth: {
        user: config.smtpUser,
        pass: config.smtpPass
    }
});

// Verify transporter
transporter.verify((error, success) => {
    if (error) {
        logger.error('SMTP connection error:', error);
    } else {
        logger.info('SMTP server is ready to take messages');
    }
});

// Email templates
const templates = {
    welcome: (name) => ({
        subject: 'Welcome to ShadowCracker',
        html: `
            <h1>Welcome to ShadowCracker, ${name}!</h1>
            <p>Thank you for joining our platform. We're excited to have you on board.</p>
            <p>If you have any questions, feel free to reach out to our support team.</p>
        `
    }),
    passwordReset: (resetToken) => ({
        subject: 'Password Reset Request',
        html: `
            <h1>Password Reset Request</h1>
            <p>You requested a password reset. Click the link below to reset your password:</p>
            <a href="${config.frontendUrl}/reset-password/${resetToken}">Reset Password</a>
            <p>If you didn't request this, please ignore this email.</p>
        `
    }),
    subscriptionConfirmation: (plan) => ({
        subject: 'Subscription Confirmation',
        html: `
            <h1>Subscription Confirmed</h1>
            <p>Thank you for subscribing to our ${plan} plan!</p>
            <p>Your subscription is now active.</p>
        `
    })
};

// Send email
const sendEmail = async (to, template, data = {}) => {
    try {
        const { subject, html } = templates[template](data);
        
        const mailOptions = {
            from: config.emailFrom,
            to,
            subject,
            html
        };

        const info = await transporter.sendMail(mailOptions);
        logger.info('Email sent:', info.messageId);
        return info;
    } catch (error) {
        logger.error('Error sending email:', error);
        throw new AppError('Failed to send email', 500);
    }
};

module.exports = {
    sendEmail
}; 