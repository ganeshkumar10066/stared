const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const config = require('../config/config');
const AppError = require('./AppError');

// Hash password
const hashPassword = async (password) => {
    try {
        const salt = await bcrypt.genSalt(config.bcryptSaltRounds);
        return bcrypt.hash(password, salt);
    } catch (error) {
        throw new AppError('Error hashing password', 500);
    }
};

// Compare password
const comparePassword = async (password, hashedPassword) => {
    try {
        return bcrypt.compare(password, hashedPassword);
    } catch (error) {
        throw new AppError('Error comparing passwords', 500);
    }
};

// Generate JWT token
const generateToken = (payload) => {
    try {
        return jwt.sign(payload, config.jwtSecret, {
            expiresIn: config.jwtExpiresIn
        });
    } catch (error) {
        throw new AppError('Error generating token', 500);
    }
};

// Verify JWT token
const verifyToken = (token) => {
    try {
        return jwt.verify(token, config.jwtSecret);
    } catch (error) {
        throw new AppError('Invalid token', 401);
    }
};

// Generate random token
const generateRandomToken = (bytes = 32) => {
    return crypto.randomBytes(bytes).toString('hex');
};

// Sanitize user data
const sanitizeUser = (user) => {
    const sanitized = { ...user.toObject() };
    delete sanitized.password;
    delete sanitized.resetPasswordToken;
    delete sanitized.resetPasswordExpires;
    return sanitized;
};

// Validate password strength
const validatePasswordStrength = (password) => {
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

    const errors = [];
    if (password.length < minLength) {
        errors.push(`Password must be at least ${minLength} characters long`);
    }
    if (!hasUpperCase) {
        errors.push('Password must contain at least one uppercase letter');
    }
    if (!hasLowerCase) {
        errors.push('Password must contain at least one lowercase letter');
    }
    if (!hasNumbers) {
        errors.push('Password must contain at least one number');
    }
    if (!hasSpecialChar) {
        errors.push('Password must contain at least one special character');
    }

    return {
        isValid: errors.length === 0,
        errors
    };
};

module.exports = {
    hashPassword,
    comparePassword,
    generateToken,
    verifyToken,
    generateRandomToken,
    sanitizeUser,
    validatePasswordStrength
}; 