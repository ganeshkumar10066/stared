const AppError = require('./AppError');

/**
 * Wraps an async function to handle errors
 * @param {Function} fn - Async function to wrap
 * @returns {Function} Express middleware function
 */
const asyncHandler = (fn) => {
    return (req, res, next) => {
        Promise.resolve(fn(req, res, next)).catch(next);
    };
};

/**
 * Wraps a controller function to handle errors and send responses
 * @param {Function} fn - Controller function to wrap
 * @returns {Function} Express middleware function
 */
const controllerHandler = (fn) => {
    return async (req, res, next) => {
        try {
            const result = await fn(req, res, next);
            if (result) {
                res.json(result);
            }
        } catch (error) {
            if (error instanceof AppError) {
                next(error);
            } else {
                next(new AppError(error.message, 500));
            }
        }
    };
};

/**
 * Wraps a service function to handle errors
 * @param {Function} fn - Service function to wrap
 * @returns {Function} Async function that handles errors
 */
const serviceHandler = (fn) => {
    return async (...args) => {
        try {
            return await fn(...args);
        } catch (error) {
            if (error instanceof AppError) {
                throw error;
            }
            throw new AppError(error.message, 500);
        }
    };
};

module.exports = {
    asyncHandler,
    controllerHandler,
    serviceHandler
}; 