const TelegramBot = require('node-telegram-bot-api');
const config = require('../config/config');
const { logger } = require('../middleware/logger');
const AppError = require('./AppError');

// Initialize bot
const bot = new TelegramBot(config.telegramBotToken, { polling: false });

// Send message to Telegram
const sendTelegramMessage = async (message) => {
    try {
        if (!config.telegramBotToken || !config.telegramChatId) {
            logger.warn('Telegram bot not configured');
            return;
        }

        const response = await bot.sendMessage(config.telegramChatId, message, {
            parse_mode: 'HTML',
            disable_web_page_preview: true
        });

        logger.info('Telegram message sent:', response.message_id);
        return response;
    } catch (error) {
        logger.error('Error sending Telegram message:', error);
        throw new AppError('Failed to send Telegram notification', 500);
    }
};

// Format error message for Telegram
const formatErrorMessage = (error, context = {}) => {
    const timestamp = new Date().toISOString();
    const contextStr = Object.entries(context)
        .map(([key, value]) => `${key}: ${value}`)
        .join('\n');

    return `
🚨 <b>Error Alert</b>
⏰ Time: ${timestamp}
❌ Error: ${error.message}
📝 Stack: ${error.stack}
${contextStr ? `\n📋 Context:\n${contextStr}` : ''}
    `.trim();
};

// Send error notification to Telegram
const sendErrorNotification = async (error, context = {}) => {
    const message = formatErrorMessage(error, context);
    return sendTelegramMessage(message);
};

module.exports = {
    sendTelegramMessage,
    sendErrorNotification
}; 