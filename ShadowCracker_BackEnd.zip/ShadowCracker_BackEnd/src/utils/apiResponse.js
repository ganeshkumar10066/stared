class ApiResponse {
    static success(data = null, message = 'Success') {
        return {
            code: 0,
            msg: message,
            data
        };
    }

    static error(message = 'Error', code = -1) {
        return {
            code,
            msg: message
        };
    }

    static paginate(data, page, limit, total) {
        return {
            code: 0,
            msg: 'Success',
            data,
            pagination: {
                page,
                limit,
                total,
                pages: Math.ceil(total / limit)
            }
        };
    }

    static list(data, total) {
        return {
            code: 0,
            msg: 'Success',
            data,
            total
        };
    }

    static created(data = null, message = 'Resource created successfully') {
        return {
            code: 0,
            msg: message,
            data
        };
    }

    static updated(data = null, message = 'Resource updated successfully') {
        return {
            code: 0,
            msg: message,
            data
        };
    }

    static deleted(message = 'Resource deleted successfully') {
        return {
            code: 0,
            msg: message
        };
    }

    static validationError(errors) {
        return {
            code: -1,
            msg: 'Validation error',
            errors
        };
    }

    static notFound(message = 'Resource not found') {
        return {
            code: -1,
            msg: message
        };
    }

    static unauthorized(message = 'Unauthorized access') {
        return {
            code: -1,
            msg: message
        };
    }

    static forbidden(message = 'Forbidden access') {
        return {
            code: -1,
            msg: message
        };
    }

    static tooManyRequests(message = 'Too many requests') {
        return {
            code: -1,
            msg: message
        };
    }

    static serverError(message = 'Internal server error') {
        return {
            code: -1,
            msg: message
        };
    }
}

module.exports = ApiResponse; 