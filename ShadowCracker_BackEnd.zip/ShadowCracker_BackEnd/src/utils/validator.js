const { body, param, query, validationResult } = require('express-validator');
const AppError = require('./AppError');

// Common validation rules
const commonRules = {
    email: body('email')
        .trim()
        .isEmail()
        .withMessage('Please provide a valid email address'),
    
    password: body('password')
        .isLength({ min: 8 })
        .withMessage('Password must be at least 8 characters long')
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)
        .withMessage('Password must contain at least one uppercase letter, one lowercase letter, one number and one special character'),
    
    objectId: param('id')
        .isMongoId()
        .withMessage('Invalid ID format'),
    
    pagination: [
        query('page')
            .optional()
            .isInt({ min: 1 })
            .withMessage('Page must be a positive integer'),
        query('limit')
            .optional()
            .isInt({ min: 1, max: 100 })
            .withMessage('Limit must be between 1 and 100')
    ]
};

// Validation middleware
const validate = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        const error = new AppError('Validation failed', 400);
        error.errors = errors.array();
        return next(error);
    }
    next();
};

// Auth validation rules
const authValidation = {
    register: [
        commonRules.email,
        commonRules.password,
        body('name')
            .trim()
            .isLength({ min: 2 })
            .withMessage('Name must be at least 2 characters long'),
        validate
    ],
    
    login: [
        commonRules.email,
        body('password')
            .notEmpty()
            .withMessage('Password is required'),
        validate
    ],
    
    resetPassword: [
        commonRules.email,
        validate
    ],
    
    updatePassword: [
        body('currentPassword')
            .notEmpty()
            .withMessage('Current password is required'),
        commonRules.password,
        validate
    ]
};

// User validation rules
const userValidation = {
    updateProfile: [
        body('name')
            .optional()
            .trim()
            .isLength({ min: 2 })
            .withMessage('Name must be at least 2 characters long'),
        body('email')
            .optional()
            .trim()
            .isEmail()
            .withMessage('Please provide a valid email address'),
        validate
    ],
    
    getById: [
        commonRules.objectId,
        validate
    ]
};

// Payment validation rules
const paymentValidation = {
    createSubscription: [
        body('planId')
            .notEmpty()
            .withMessage('Plan ID is required'),
        validate
    ],
    
    webhook: [
        body('type')
            .notEmpty()
            .withMessage('Event type is required'),
        validate
    ]
};

module.exports = {
    commonRules,
    validate,
    authValidation,
    userValidation,
    paymentValidation
}; 