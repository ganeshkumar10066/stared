const Redis = require('ioredis');
const config = require('../config/config');
const { logger } = require('../middleware/logger');
const AppError = require('./AppError');

// Initialize Redis client
const redis = new Redis(config.redisUrl, {
    retryStrategy: (times) => {
        const delay = Math.min(times * 50, 2000);
        return delay;
    }
});

// Handle Redis connection events
redis.on('connect', () => {
    logger.info('Redis connected');
});

redis.on('error', (error) => {
    logger.error('Redis error:', error);
});

// Cache middleware
const cache = (duration = config.cacheTTL) => {
    return async (req, res, next) => {
        if (req.method !== 'GET') {
            return next();
        }

        const key = `cache:${req.originalUrl}`;

        try {
            const cachedResponse = await redis.get(key);
            if (cachedResponse) {
                return res.json(JSON.parse(cachedResponse));
            }

            // Store original res.json
            const originalJson = res.json;

            // Override res.json method
            res.json = function (body) {
                redis.setex(key, duration, JSON.stringify(body))
                    .catch(err => logger.error('Redis set error:', err));
                return originalJson.call(this, body);
            };

            next();
        } catch (error) {
            logger.error('Cache error:', error);
            next();
        }
    };
};

// Clear cache for a specific key
const clearCache = async (key) => {
    try {
        await redis.del(key);
        logger.info(`Cache cleared for key: ${key}`);
    } catch (error) {
        logger.error('Error clearing cache:', error);
        throw new AppError('Failed to clear cache', 500);
    }
};

// Clear cache by pattern
const clearCacheByPattern = async (pattern) => {
    try {
        const keys = await redis.keys(pattern);
        if (keys.length > 0) {
            await redis.del(keys);
            logger.info(`Cache cleared for pattern: ${pattern}`);
        }
    } catch (error) {
        logger.error('Error clearing cache by pattern:', error);
        throw new AppError('Failed to clear cache by pattern', 500);
    }
};

module.exports = {
    redis,
    cache,
    clearCache,
    clearCacheByPattern
}; 