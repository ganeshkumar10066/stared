const rateLimit = require('express-rate-limit');
const AppError = require('../utils/AppError');

const createRateLimiter = (windowMs, max, message) => {
    return rateLimit({
        windowMs,
        max,
        message: AppError.rateLimit(message),
        standardHeaders: true,
        legacyHeaders: false,
    });
};

// General API rate limiter
const apiLimiter = createRateLimiter(
    15 * 60 * 1000, // 15 minutes
    100, // 100 requests per window
    'Too many requests from this IP, please try again after 15 minutes'
);

// Stricter limiter for authentication endpoints
const authLimiter = createRateLimiter(
    60 * 60 * 1000, // 1 hour
    5, // 5 requests per window
    'Too many login attempts, please try again after an hour'
);

// Stricter limiter for password reset
const passwordResetLimiter = createRateLimiter(
    60 * 60 * 1000, // 1 hour
    3, // 3 requests per window
    'Too many password reset attempts, please try again after an hour'
);

module.exports = {
    apiLimiter,
    authLimiter,
    passwordResetLimiter
}; 