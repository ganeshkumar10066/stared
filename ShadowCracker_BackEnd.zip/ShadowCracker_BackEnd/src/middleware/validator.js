const { validationResult } = require('express-validator');
const AppError = require('../utils/AppError');

const validate = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        const error = AppError.validationError('Validation failed');
        error.errors = errors.array();
        return next(error);
    }
    next();
};

const validateObjectId = (id) => {
    return /^[0-9a-fA-F]{24}$/.test(id);
};

const validateEmail = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};

const validatePassword = (password) => {
    // At least 8 characters, 1 uppercase, 1 lowercase, 1 number
    return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/.test(password);
};

module.exports = {
    validate,
    validateObjectId,
    validateEmail,
    validatePassword
}; 