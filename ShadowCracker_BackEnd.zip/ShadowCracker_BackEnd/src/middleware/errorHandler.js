const { sendTelegramMessage } = require('../utils/telegramBot');

const errorHandler = (err, req, res, next) => {
    console.error('Error:', err);

    // Log error to Telegram if it's a critical error
    if (err.isCritical) {
        sendTelegramMessage(`❌ Critical Error:\n${err.message}\nStack: ${err.stack}`)
            .catch(console.error);
    }

    // Handle specific error types
    if (err.name === 'ValidationError') {
        return res.status(400).json({
            code: -1,
            msg: 'Validation error',
            errors: err.errors
        });
    }

    if (err.name === 'UnauthorizedError') {
        return res.status(401).json({
            code: -1,
            msg: 'Unauthorized access'
        });
    }

    if (err.name === 'RateLimitError') {
        return res.status(429).json({
            code: -1,
            msg: 'Rate limit exceeded'
        });
    }

    // Default error response
    res.status(err.status || 500).json({
        code: -1,
        msg: err.message || 'Internal server error',
        ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
    });
};

module.exports = { errorHandler }; 