// Payment Gateway Configuration
module.exports = {
    mchId: '8891367',
    apiKey: 'f7b3eb7e62f0c439763048c403ee158a',
    apiUrl: 'https://xyu10.top/api/payquery/payCollect',
    signType: 'MD5'
}; 