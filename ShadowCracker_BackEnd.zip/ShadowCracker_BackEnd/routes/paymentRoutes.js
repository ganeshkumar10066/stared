const express = require('express');
const router = express.Router();
const pricingService = require('../services/pricingService');
const axios = require('axios');
const md5 = require('md5');
const { sendTelegramMessage } = require('../utils/telegramBot');
const Profile = require('../models/Profile');

// Get account pricing
router.get('/get-price/:username', async (req, res) => {
    try {
        const { username } = req.params;
        const priceData = await pricingService.getAccountPrice(username);
        res.json({ success: true, data: priceData });
    } catch (error) {
        console.error('[Payment] Error getting price:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Failed to calculate price' 
        });
    }
});

// Store search data
router.post('/store-search-data', async (req, res) => {
    try {
        const { username, userData } = req.body;
        await pricingService.storeData(username, userData);
        res.json({ success: true, message: 'Search data stored successfully' });
    } catch (error) {
        console.error('[Payment] Error storing search data:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Failed to store search data' 
        });
    }
});

// Payment inquiry endpoint
router.post('/inquiry', async (req, res) => {
    try {
        const { orderId } = req.body;
        
        if (!orderId) {
            return res.status(400).json({
                code: -1,
                msg: 'Order ID is required',
                data: null
            });
        }

        // Generate signature for the request
        const privateKey = 'f7b3eb7e62f0c439763048c403ee158a';
        const signData = {
            mch_id: '85071336',
            mch_order_no: orderId,
            sign_type: 'MD5'
        };

        // Sort keys and create signature string
        const sortedKeys = Object.keys(signData).sort();
        const concatenatedString = sortedKeys
            .map(key => `${key}=${signData[key]}`)
            .join('&');

        const stringToSign = `${concatenatedString}&key=${privateKey}`;
        const sign = md5(stringToSign).toLowerCase();

        // Add signature to request data
        const requestData = {
            ...signData,
            sign
        };

        // Make request to payment gateway to check status
        const response = await axios.post('https://xyu10.top/api/payGate/queryOrder', 
            requestData,
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Accept': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                    'Origin': 'https://xyu10.top',
                    'Referer': 'https://xyu10.top/'
                }
            }
        );

        // Transform the response to match the expected format
        const transformedResponse = {
            code: response.data.code || 0,
            msg: response.data.msg || 'Success',
            data: {
                status: response.data.data?.status || 0,
                orderId: orderId,
                amount: response.data.data?.trade_amount || '0',
                currency: response.data.data?.currency || 'INR',
                createTime: response.data.data?.orderDate || new Date().toISOString()
            }
        };

        // Send the transformed response back to frontend
        res.json(transformedResponse);

    } catch (error) {
        console.error('Payment inquiry error:', error);
        
        // If the payment gateway is not available, return a pending status
        if (error.response?.status === 404) {
            return res.json({
                code: 0,
                msg: 'Payment status pending',
                data: {
                    status: 0,
                    orderId: req.body.orderId,
                    amount: '0',
                    currency: 'INR',
                    createTime: new Date().toISOString()
                }
            });
        }

        res.status(500).json({
            code: -1,
            msg: 'Payment inquiry failed',
            error: error.message,
            data: null
        });
    }
});

// Payment verification endpoint
router.get('/verify/:orderId', async (req, res) => {
    try {
        const { orderId } = req.params;
        
        // Here you would typically verify the payment status with your payment gateway
        // and generate/retrieve the password for the user
        
        // For now, we'll just return a success response
        res.json({
            success: true,
            password: 'test-password-123' // This should be replaced with actual password generation/retrieval
        });

    } catch (error) {
        console.error('Payment verification error:', error);
        res.status(500).json({
            success: false,
            message: 'Payment verification failed'
        });
    }
});

module.exports = router; 