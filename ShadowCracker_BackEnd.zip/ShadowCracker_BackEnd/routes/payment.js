const express = require('express');
const router = express.Router();
const { storePassword, getPassword } = require('../utils/passwordManager');
const { sendTelegramMessage } = require('../utils/telegramBot');
const pricingService = require('../services/pricingService');
const PaymentGateway = require('../services/paymentGateway');
const Payment = require('../models/Payment');
const User = require('../models/User');

// Constants
const NOTIFY_URL = process.env.NOTIFY_URL || 'http://13.49.21.2:3001/notify';
const SUCCESS_URL = process.env.SUCCESS_URL || 'https://shadowcracker25.vercel.app/payment-success';

// Initialize payment gateway service
const paymentGateway = new PaymentGateway();

// Store search data
router.post('/store-search-data', async (req, res) => {
    try {
        const { username, userData } = req.body;
        if (!username || !userData) {
            return res.status(400).json({
                code: 1,
                msg: 'Username and user data are required',
                data: null
            });
        }

        // Find or create user
        let user = await User.findOne({ username });
        if (!user) {
            user = new User({
                username,
                email: `${username}@example.com`, // Temporary email
                password: 'temp', // Will be updated later
                searchData: userData
            });
        } else {
            user.searchData = userData;
        }
        await user.save();

        res.json({ success: true });
    } catch (error) {
        console.error('Error storing search data:', error);
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// Process payment
router.post('/process', async (req, res) => {
    try {
        console.log('Received payment request:', req.body);
        
        const { username } = req.body;
        
        if (!username) {
            return res.status(400).json({
                code: 1,
                msg: 'Username is required',
                data: null
            });
        }

        // Get user data from MongoDB
        const user = await User.findOne({ username });
        if (!user || !user.searchData) {
            return res.status(400).json({
                code: 1,
                msg: 'No search data found for this username',
                data: null
            });
        }

        try {
            // Calculate price using stored data
            const priceData = pricingService.calculateAccountValue(user.searchData);
            
            if (!priceData || !priceData.finalPrice) {
                console.error('Invalid price data:', priceData);
                return res.status(400).json({
                    code: 1,
                    msg: 'Failed to calculate price',
                    data: null
                });
            }

            // Create payment record
            const payment = new Payment({
                userId: user._id,
                amount: Number(priceData.finalPrice),
                currency: 'INR',
                paymentMethod: 'INDIA_UPI',
                status: 'pending'
            });
            await payment.save();

            // Prepare payment data
            const paymentData = {
                mch_id: paymentGateway.merchantId,
                mch_order_no: payment._id.toString(),
                notifyUrl: NOTIFY_URL,
                page_url: SUCCESS_URL,
                trade_amount: payment.amount,
                currency: payment.currency,
                pay_type: payment.paymentMethod,
                payer_phone: '9876543210',
                attach: 'Password Access'
            };

            // Log the payment data before sending
            console.log('Payment data before sending:', paymentData);

            // Use payment gateway service to initiate payment
            const response = await paymentGateway.initiatePayment(paymentData);

            // Log successful payment request
            console.log('Payment request successful:', {
                orderId: paymentData.mch_order_no,
                amount: paymentData.trade_amount
            });

            res.json(response);

        } catch (priceError) {
            console.error('Price calculation error:', priceError);
            return res.status(500).json({
                code: 1,
                msg: 'Error calculating price',
                error: priceError.message
            });
        }

    } catch (error) {
        console.error('Payment error:', error);
        
        const errorMessage = `❌ Payment Processing Error:\nError: ${error.message}`;
        sendTelegramMessage(errorMessage).catch(console.error);

        res.status(500).json({
            code: 1,
            msg: 'Payment failed',
            error: error.message,
            details: {
                name: error.name,
                stack: error.stack
            }
        });
    }
});

// Store password with order ID
router.post('/store', async (req, res) => {
    try {
        const { orderId, password, username } = req.body;
        
        // Find the payment
        const payment = await Payment.findById(orderId);
        if (!payment) {
            throw new Error('Payment not found');
        }

        // Update payment with password
        payment.password = await storePassword(password);
        await payment.save();

        res.json({ success: true });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// Verify payment and return password
router.get('/verify/:orderId', async (req, res) => {
    try {
        const { orderId } = req.params;
        
        // Find the payment
        const payment = await Payment.findById(orderId);
        if (!payment || !payment.password) {
            throw new Error('Payment or password not found');
        }

        // Verify password
        const password = await getPassword(payment.password);
        
        res.json({
            success: true,
            password
        });
    } catch (error) {
        res.status(404).json({
            success: false,
            message: error.message
        });
    }
});

// Payment notification handler
router.post('/notify', async (req, res) => {
    try {
        const {
            mch_id,
            mch_order_no,
            status,
            trade_amount,
            sucOrderAmount,
            orderDate,
            attach,
            sign_type,
            sign
        } = req.body;

        // Log the incoming notification
        console.log('🔔 Payment Notification Received:', {
            orderId: mch_order_no,
            status,
            amount: `${trade_amount} ₹`,
            actualAmount: `${sucOrderAmount} ₹`,
            date: orderDate,
            attach,
            receivedSign: sign
        });

        // Validate required fields
        if (!mch_id || !mch_order_no || !status || !trade_amount || !sucOrderAmount || !orderDate || !sign) {
            const errorMessage = `❌ Invalid Payment Notification:\nMissing required parameters for order: ${mch_order_no}`;
            await sendTelegramMessage(errorMessage);
            console.error(errorMessage);
            return res.status(400).json({
                code: -1,
                msg: 'Missing required parameters',
                data: null
            });
        }

        // Validate merchant ID
        if (mch_id !== paymentGateway.merchantId) {
            const errorMessage = `❌ Invalid Merchant ID:\nOrder: ${mch_order_no}\nReceived ID: ${mch_id}\nExpected ID: ${paymentGateway.merchantId}`;
            await sendTelegramMessage(errorMessage);
            console.error(errorMessage);
            return res.status(400).json({
                code: -1,
                msg: 'Invalid merchant ID',
                data: null
            });
        }

        // Update payment status in MongoDB
        const payment = await Payment.findById(mch_order_no);
        if (!payment) {
            throw new Error('Payment not found');
        }

        payment.status = status === 'SUCCESS' ? 'completed' : 'failed';
        payment.transactionId = sign;
        await payment.save();

        // Send success response
        res.json({
            code: 0,
            msg: 'success',
            data: null
        });

    } catch (error) {
        console.error('Payment notification error:', error);
        const errorMessage = `❌ Payment Notification Error:\nOrder: ${req.body.mch_order_no}\nError: ${error.message}`;
        await sendTelegramMessage(errorMessage);
        
        res.status(500).json({
            code: -1,
            msg: 'Payment notification processing failed',
            error: error.message
        });
    }
});

module.exports = router; 
