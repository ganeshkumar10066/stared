const axios = require('axios');
const assert = require('assert');

const BASE_URL = 'http://localhost:3001';
const TEST_USERNAME = 'test_user';

// Test data
const mockUserData = {
    username: TEST_USERNAME,
    edge_followed_by: { count: 50000 },
    is_verified: true,
    is_business_account: true,
    is_professional_account: true,
    edge_follow: { count: 1000 },
    edge_owner_to_timeline_media: { count: 100 },
    highlight_reel_count: 5
};

async function runTests() {
    console.log('🚀 Starting API Tests...\n');

    try {
        // Test 1: Store Search Data
        console.log('📝 Test 1: Store Search Data');
        const storeResponse = await axios.post(`${BASE_URL}/payment/store-search-data/${TEST_USERNAME}`, {
            userData: mockUserData
        });
        console.log('Store response:', storeResponse.data);
        assert.strictEqual(storeResponse.data.success, true);
        console.log('✅ Search data stored successfully\n');

        // Test 2: Error Handling - Invalid Username
        console.log('❌ Test 2: Error Handling - Invalid Username');
        try {
            await axios.post(`${BASE_URL}/payment/store-search-data/invalid_username`, {
                userData: mockUserData
            });
            assert.fail('Should have thrown an error');
        } catch (error) {
            console.log('Error response:', error.response?.data);
            assert.strictEqual(error.response.status, 400);
            console.log('✅ Error handling for invalid username successful\n');
        }

        // Test 3: Error Handling - Missing User Data
        console.log('❌ Test 3: Error Handling - Missing User Data');
        try {
            await axios.post(`${BASE_URL}/payment/store-search-data/${TEST_USERNAME}`, {});
            assert.fail('Should have thrown an error');
        } catch (error) {
            console.log('Error response:', error.response?.data);
            assert.strictEqual(error.response.status, 400);
            console.log('✅ Error handling for missing user data successful\n');
        }

        console.log('🎉 All tests completed successfully!');

    } catch (error) {
        console.error('❌ Test failed:', error.message);
        if (error.response) {
            console.error('Response data:', error.response.data);
            console.error('Response status:', error.response.status);
            console.error('Response headers:', error.response.headers);
        }
        process.exit(1);
    }
}

// Run the tests
runTests(); 