const pricingService = require('./services/pricingService');

async function testPricing() {
    try {
        console.log('Testing pricing calculation for username: dhhruv0');
        const priceData = await pricingService.getAccountPrice('rolex');
        console.log('Price calculation result:', JSON.stringify(priceData, null, 2));
    } catch (error) {
        console.error('Error testing pricing:', error);
    }
}

testPricing(); 