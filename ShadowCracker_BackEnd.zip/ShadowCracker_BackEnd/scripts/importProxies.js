const mongoose = require('mongoose');
const Proxy = require('../models/Proxy');
const connectDB = require('../config/db');

const proxies = [
    {
        host: '198.23.239.134',
        port: 6540,
        username: 'iiukzukr',
        password: '2anbpukm09xk',
        protocol: 'http',
        isActive: true
    },
    {
        host: '207.244.217.165',
        port: 6712,
        username: 'iiukzukr',
        password: '2anbpukm09xk',
        protocol: 'http',
        isActive: true
    },
    {
        host: '107.172.163.27',
        port: 6543,
        username: 'iiukzukr',
        password: '2anbpukm09xk',
        protocol: 'http',
        isActive: true
    },
    {
        host: '161.123.152.115',
        port: 6360,
        username: 'iiukzukr',
        password: '2anbpukm09xk',
        protocol: 'http',
        isActive: true
    },
    {
        host: '23.94.138.75',
        port: 6349,
        username: 'iiukzukr',
        password: '2anbpukm09xk',
        protocol: 'http',
        isActive: true
    },
    {
        host: '216.10.27.159',
        port: 6837,
        username: 'iiukzukr',
        password: '2anbpukm09xk',
        protocol: 'http',
        isActive: true
    },
    {
        host: '136.0.207.84',
        port: 6661,
        username: 'iiukzukr',
        password: '2anbpukm09xk',
        protocol: 'http',
        isActive: true
    },
    {
        host: '64.64.118.149',
        port: 6732,
        username: 'iiukzukr',
        password: '2anbpukm09xk',
        protocol: 'http',
        isActive: true
    },
    {
        host: '142.147.128.93',
        port: 6593,
        username: 'iiukzukr',
        password: '2anbpukm09xk',
        protocol: 'http',
        isActive: true
    },
    {
        host: '154.36.110.199',
        port: 6853,
        username: 'iiukzukr',
        password: '2anbpukm09xk',
        protocol: 'http',
        isActive: true
    }
];

async function importProxies() {
    try {
        // Connect to database
        await connectDB();

        // Clear existing proxies
        await Proxy.deleteMany({});

        // Insert new proxies
        const result = await Proxy.insertMany(proxies);
        console.log(`Successfully imported ${result.length} proxies`);

        // Disconnect from database
        await mongoose.disconnect();
        console.log('Database disconnected');
    } catch (error) {
        console.error('Error importing proxies:', error);
        process.exit(1);
    }
}

// Run the import
importProxies(); 