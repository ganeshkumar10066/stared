const axios = require('axios');

async function testPaymentRoutes() {
    console.log('🧪 Testing Payment Routes Fix...\n');

    const baseUrl = 'http://localhost:3001';

    try {
        // Test 1: Payment Inquiry
        console.log('1️⃣ Testing Payment Inquiry...');
        const inquiryResponse = await axios.post(`${baseUrl}/api/payment/inquiry`, {
            orderId: 'TEST_ORDER_123'
        });
        
        console.log('✅ Inquiry Response:', {
            code: inquiryResponse.data.code,
            msg: inquiryResponse.data.msg,
            hasData: !!inquiryResponse.data.data
        });

        // Test 2: Payment Process
        console.log('\n2️⃣ Testing Payment Process...');
        const processResponse = await axios.post(`${baseUrl}/api/payment/process`, {
            username: 'testuser',
            userData: {
                finalPrice: 100,
                phone: '1234567890'
            }
        });
        
        console.log('✅ Process Response:', {
            code: processResponse.data.code,
            msg: processResponse.data.msg,
            hasData: !!processResponse.data.data
        });

        // Test 3: Get Price
        console.log('\n3️⃣ Testing Get Price...');
        const priceResponse = await axios.get(`${baseUrl}/api/payment/get-price/testuser`);
        
        console.log('✅ Price Response:', {
            code: priceResponse.data.code,
            msg: priceResponse.data.msg,
            hasData: !!priceResponse.data.data
        });

        console.log('\n🎉 All route tests completed successfully!');

    } catch (error) {
        console.error('❌ Route test failed:', error.response?.data || error.message);
    }
}

// Run the test if this file is executed directly
if (require.main === module) {
    testPaymentRoutes();
}

module.exports = { testPaymentRoutes }; 