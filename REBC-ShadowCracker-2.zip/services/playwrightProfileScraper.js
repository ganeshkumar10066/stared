const { chromium } = require('playwright');
const PQueue = require('p-queue').default;

const API_URL = 'https://anonyig.com/api/v1/instagram/userInfo';
const VIEWER_URL = 'https://anonyig.com/en/instagram-profile-viewer/';
const BROWSER_POOL_SIZE = 2; // Reduced from 3 to avoid overwhelming the target site
const PAGES_PER_BROWSER = 5; // Reduced from 9 to improve stability
const MAX_QUEUE_SIZE = 300; // Reduced from 500
const MAX_TOTAL_PAGES = BROWSER_POOL_SIZE * PAGES_PER_BROWSER;
const MAX_RETRIES = 3; // Add retry mechanism
const INITIAL_TIMEOUT = 30000; // Increased from 15000
const PAGE_LOAD_TIMEOUT = 45000; // Increased timeout for page loading

// Performance optimizations
const BROWSER_OPTIONS = {
  headless: true,
  args: [
    '--no-sandbox',
    '--disable-setuid-sandbox',
    '--disable-dev-shm-usage',
    '--disable-accelerated-2d-canvas',
    '--no-first-run',
    '--no-zygote',
    '--disable-gpu',
    '--disable-background-timer-throttling',
    '--disable-backgrounding-occluded-windows',
    '--disable-renderer-backgrounding',
    '--disable-features=TranslateUI',
    '--disable-ipc-flooding-protection',
    '--memory-pressure-off',
    '--max_old_space_size=4096',
    '--disable-web-security',
    '--disable-features=VizDisplayCompositor',
    '--disable-extensions',
    '--disable-plugins',
    '--disable-images',
    '--disable-javascript-harmony-shipping',
    '--disable-default-apps',
    '--disable-sync',
    '--disable-translate',
    '--hide-scrollbars',
    '--mute-audio',
    '--no-default-browser-check',
    '--no-pings',
    '--disable-background-networking',
    // Cloudflare bypass and performance optimizations
    '--disable-blink-features=AutomationControlled',
    '--disable-features=VizDisplayCompositor,VizHitTestSurfaceLayer',
    '--disable-ipc-flooding-protection',
    '--disable-renderer-backgrounding',
    '--disable-backgrounding-occluded-windows',
    '--disable-background-timer-throttling',
    '--disable-features=TranslateUI,BlinkGenPropertyTrees',
    '--disable-ipc-flooding-protection',
    '--disable-background-networking',
    '--disable-default-apps',
    '--disable-extensions',
    '--disable-sync',
    '--disable-translate',
    '--hide-scrollbars',
    '--mute-audio',
    '--no-default-browser-check',
    '--no-pings',
    '--no-zygote',
    '--disable-gpu-sandbox',
    '--disable-software-rasterizer',
    '--disable-dev-shm-usage',
    '--disable-setuid-sandbox',
    '--no-sandbox',
    '--disable-web-security',
    '--disable-features=VizDisplayCompositor',
    '--disable-background-timer-throttling',
    '--disable-backgrounding-occluded-windows',
    '--disable-renderer-backgrounding',
    '--disable-features=TranslateUI',
    '--disable-ipc-flooding-protection',
    '--memory-pressure-off',
    '--max_old_space_size=4096',
    '--disable-extensions',
    '--disable-plugins',
    '--disable-images',
    '--disable-javascript-harmony-shipping',
    '--disable-default-apps',
    '--disable-sync',
    '--disable-translate',
    '--hide-scrollbars',
    '--mute-audio',
    '--no-default-browser-check',
    '--no-pings',
    '--disable-background-networking',
    // Additional performance flags
    '--aggressive-cache-discard',
    '--disable-cache',
    '--disable-application-cache',
    '--disable-offline-load-stale-cache',
    '--disk-cache-size=0',
    '--disable-background-networking',
    '--disable-sync-preferences',
    '--disable-default-apps',
    '--disable-extensions',
    '--disable-plugins',
    '--disable-images',
    '--disable-javascript-harmony-shipping',
    '--disable-default-apps',
    '--disable-sync',
    '--disable-translate',
    '--hide-scrollbars',
    '--mute-audio',
    '--no-default-browser-check',
    '--no-pings',
    '--disable-background-networking',
    '--disable-features=VizDisplayCompositor',
    '--disable-background-timer-throttling',
    '--disable-backgrounding-occluded-windows',
    '--disable-renderer-backgrounding',
    '--disable-features=TranslateUI',
    '--disable-ipc-flooding-protection',
    '--memory-pressure-off',
    '--max_old_space_size=4096',
    '--disable-extensions',
    '--disable-plugins',
    '--disable-images',
    '--disable-javascript-harmony-shipping',
    '--disable-default-apps',
    '--disable-sync',
    '--disable-translate',
    '--hide-scrollbars',
    '--mute-audio',
    '--no-default-browser-check',
    '--no-pings',
    '--disable-background-networking'
  ]
};

const CONTEXT_OPTIONS = {
  userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
  viewport: { width: 1920, height: 1080 },
  deviceScaleFactor: 1,
  isMobile: false,
  hasTouch: false,
  javaScriptEnabled: true,
  acceptDownloads: false,
  ignoreHTTPSErrors: true,
  // Cloudflare bypass headers
  extraHTTPHeaders: {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Sec-Ch-Ua': '"Not A(Brand";v="99", "Google Chrome";v="121", "Chromium";v="121"',
    'Sec-Ch-Ua-Mobile': '?0',
    'Sec-Ch-Ua-Platform': '"Windows"',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'
  }
};

const pagePools = [];
const browsers = [];

// Retry helper function with exponential backoff
async function retryWithBackoff(fn, maxRetries = MAX_RETRIES, baseDelay = 1000) {
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      if (attempt === maxRetries) {
        throw error;
      }
      
      const delay = baseDelay * Math.pow(2, attempt);
      console.log(`[Playwright] Retry attempt ${attempt + 1}/${maxRetries + 1} after ${delay}ms delay`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
}

// Status for monitoring
function getStatus() {
  return {
    browsers: browsers.length,
    pages: pagePools.length,
    queues: pagePools.map((pool, idx) => ({
      index: idx,
      queueSize: pool.queue.size,
      queuePending: pool.queue.pending,
      isClosed: pool.page.isClosed ? pool.page.isClosed() : false
    })),
    maxTotalPages: MAX_TOTAL_PAGES,
    maxQueueSize: MAX_QUEUE_SIZE
  };
}

async function createPagePool() {
  const browser = await chromium.launch(BROWSER_OPTIONS);
  const context = await browser.newContext(CONTEXT_OPTIONS);
  
  // Optimize page performance
  const page = await context.newPage();
  
  // Advanced ad blocking and resource filtering for faster loading
  await page.route('**/*', (route) => {
    const url = route.request().url();
    const resourceType = route.request().resourceType();
    
    // Block ads, analytics, and tracking
    const blockedDomains = [
      'google-analytics.com', 'googletagmanager.com', 'facebook.com', 'doubleclick.net',
      'googlesyndication.com', 'amazon-adsystem.com', 'adnxs.com', 'adsystem.com',
      'adtech.com', 'advertising.com', 'moatads.com', 'scorecardresearch.com',
      'quantserve.com', 'hotjar.com', 'mixpanel.com', 'amplitude.com',
      'segment.com', 'optimizely.com', 'vwo.com', 'crazyegg.com',
      'clicktale.com', 'inspectlet.com', 'mouseflow.com', 'fullstory.com',
      'logrocket.com', 'sentry.io', 'rollbar.com', 'bugsnag.com',
      'cloudflare.com', 'cdnjs.cloudflare.com', 'jsdelivr.net', 'unpkg.com',
      'bootstrapcdn.com', 'cdn.jsdelivr.net', 'cdnjs.cloudflare.com',
      'fonts.googleapis.com', 'fonts.gstatic.com', 'ajax.googleapis.com',
      'code.jquery.com', 'cdn.jsdelivr.net', 'unpkg.com', 'npmjs.com'
    ];
    
    // Block unnecessary resource types
    const blockedTypes = ['image', 'stylesheet', 'font', 'media', 'other'];
    
    // Check if URL contains blocked domains
    const isBlockedDomain = blockedDomains.some(domain => url.includes(domain));
    
    // Block ads and unnecessary resources
    if (isBlockedDomain || blockedTypes.includes(resourceType)) {
      route.abort();
    } else {
      // Add anti-detection headers
      const headers = {
        ...route.request().headers(),
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Upgrade-Insecure-Requests': '1'
      };
      route.continue({ headers });
    }
  });
  
  // Anti-detection measures
  await page.addInitScript(() => {
    // Remove webdriver property
    Object.defineProperty(navigator, 'webdriver', {
      get: () => undefined,
    });
    
    // Override plugins
    Object.defineProperty(navigator, 'plugins', {
      get: () => [1, 2, 3, 4, 5],
    });
    
    // Override languages
    Object.defineProperty(navigator, 'languages', {
      get: () => ['en-US', 'en'],
    });
    
    // Override permissions
    const originalQuery = window.navigator.permissions.query;
    window.navigator.permissions.query = (parameters) => (
      parameters.name === 'notifications' ?
        Promise.resolve({ state: Notification.permission }) :
        originalQuery(parameters)
    );
    
    // Override chrome runtime
    window.chrome = {
      runtime: {},
    };
    
    // Override permissions
    const originalGetProperty = Object.getOwnPropertyDescriptor;
    Object.getOwnPropertyDescriptor = function(obj, prop) {
      if (prop === 'webdriver') {
        return undefined;
      }
      return originalGetProperty.call(this, obj, prop);
    };
  });

  // Use retry mechanism for page loading with Cloudflare bypass
  await retryWithBackoff(async () => {
    await page.goto(VIEWER_URL, { 
      timeout: PAGE_LOAD_TIMEOUT,
      waitUntil: 'domcontentloaded' 
    });
    
    // Wait for Cloudflare challenge to complete if present
    try {
      await page.waitForFunction(() => {
        return !document.querySelector('#challenge-form') && 
               !document.querySelector('.cf-browser-verification') &&
               !document.querySelector('#cf-please-wait');
      }, { timeout: 10000 });
    } catch (error) {
      console.log('[Playwright] Cloudflare challenge not detected or already passed');
    }
  });
  
  const queue = new PQueue({ 
    concurrency: 1, // Reduced from 2 for better stability
    timeout: 60000 // Increased from 30000
  });
  
  browsers.push(browser);
  pagePools.push({ page, queue, context });
  return pagePools.length - 1;
}

async function searchOnPage(page, username) {
  try {
    if (page.isClosed && page.isClosed()) {
      throw new Error('Page is closed');
    }
    
    // Check for Cloudflare challenge and wait if needed
    try {
      await page.waitForFunction(() => {
        return !document.querySelector('#challenge-form') && 
               !document.querySelector('.cf-browser-verification') &&
               !document.querySelector('#cf-please-wait');
      }, { timeout: 5000 });
    } catch (error) {
      console.log(`[Playwright] Waiting for Cloudflare challenge to complete for ${username}`);
      await page.waitForTimeout(3000);
    }
    
    // Wait for the search input to be available
    await page.waitForSelector('input[placeholder="@username or link"]', { timeout: 10000 });
    
    // Clear input more efficiently
    await page.evaluate(() => {
      const input = document.querySelector('input[placeholder="@username or link"]');
      if (input) input.value = '';
    });
    
    // Add random delay to mimic human behavior
    await page.waitForTimeout(Math.random() * 1000 + 500);
    
    await page.fill('input[placeholder="@username or link"]', username);
    
    // Add random delay before pressing Enter
    await page.waitForTimeout(Math.random() * 500 + 200);
    await page.keyboard.press('Enter');
    
    let userInfoResponse = null;
    try {
      userInfoResponse = await page.waitForResponse(
        response => response.url().startsWith(API_URL),
        { timeout: 20000 } // Increased from 10000
      ).then(res => res.json());
    } catch (err) {
      if (err.name === 'TimeoutError') {
        try {
          // Retry with page reload
          await retryWithBackoff(async () => {
            await page.reload({ 
              timeout: PAGE_LOAD_TIMEOUT,
              waitUntil: 'domcontentloaded' 
            });
          });
        } catch (reloadErr) {
          console.error(`[Playwright] Page reload failed for ${username}:`, reloadErr);
        }
      }
      userInfoResponse = null;
      console.error(`[Playwright] Error waiting for API response for ${username}:`, err);
    }
    

    if (userInfoResponse) {
      return userInfoResponse;
    } else {
      return { error: 'timeout_or_no_data' };
    }
  } catch (err) {
    console.error(`[Playwright] searchOnPage internal error for ${username}:`, err);
    return { error: 'internal_error', details: err.message };
  }
}

async function startMinimalPool() {
  console.log(`[Playwright] Starting minimal pool with ${BROWSER_POOL_SIZE} browsers and ${PAGES_PER_BROWSER} pages each`);
  
  for (let i = 0; i < BROWSER_POOL_SIZE; i++) {
    try {
      const browser = await chromium.launch(BROWSER_OPTIONS);
      browsers.push(browser);
      
      for (let j = 0; j < PAGES_PER_BROWSER; j++) {
        try {
          const context = await browser.newContext(CONTEXT_OPTIONS);
          const page = await context.newPage();
          
          // Advanced ad blocking and resource filtering for faster loading
          await page.route('**/*', (route) => {
            const url = route.request().url();
            const resourceType = route.request().resourceType();
            
            // Block ads, analytics, and tracking
            const blockedDomains = [
              'google-analytics.com', 'googletagmanager.com', 'facebook.com', 'doubleclick.net',
              'googlesyndication.com', 'amazon-adsystem.com', 'adnxs.com', 'adsystem.com',
              'adtech.com', 'advertising.com', 'moatads.com', 'scorecardresearch.com',
              'quantserve.com', 'hotjar.com', 'mixpanel.com', 'amplitude.com',
              'segment.com', 'optimizely.com', 'vwo.com', 'crazyegg.com',
              'clicktale.com', 'inspectlet.com', 'mouseflow.com', 'fullstory.com',
              'logrocket.com', 'sentry.io', 'rollbar.com', 'bugsnag.com',
              'cloudflare.com', 'cdnjs.cloudflare.com', 'jsdelivr.net', 'unpkg.com',
              'bootstrapcdn.com', 'cdn.jsdelivr.net', 'cdnjs.cloudflare.com',
              'fonts.googleapis.com', 'fonts.gstatic.com', 'ajax.googleapis.com',
              'code.jquery.com', 'cdn.jsdelivr.net', 'unpkg.com', 'npmjs.com'
            ];
            
            // Block unnecessary resource types
            const blockedTypes = ['image', 'stylesheet', 'font', 'media', 'other'];
            
            // Check if URL contains blocked domains
            const isBlockedDomain = blockedDomains.some(domain => url.includes(domain));
            
            // Block ads and unnecessary resources
            if (isBlockedDomain || blockedTypes.includes(resourceType)) {
              route.abort();
            } else {
              // Add anti-detection headers
              const headers = {
                ...route.request().headers(),
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.9',
                'Cache-Control': 'no-cache',
                'Pragma': 'no-cache',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'none',
                'Upgrade-Insecure-Requests': '1'
              };
              route.continue({ headers });
            }
          });
          
          // Anti-detection measures
          await page.addInitScript(() => {
            // Remove webdriver property
            Object.defineProperty(navigator, 'webdriver', {
              get: () => undefined,
            });
            
            // Override plugins
            Object.defineProperty(navigator, 'plugins', {
              get: () => [1, 2, 3, 4, 5],
            });
            
            // Override languages
            Object.defineProperty(navigator, 'languages', {
              get: () => ['en-US', 'en'],
            });
            
            // Override permissions
            const originalQuery = window.navigator.permissions.query;
            window.navigator.permissions.query = (parameters) => (
              parameters.name === 'notifications' ?
                Promise.resolve({ state: Notification.permission }) :
                originalQuery(parameters)
            );
            
            // Override chrome runtime
            window.chrome = {
              runtime: {},
            };
            
            // Override permissions
            const originalGetProperty = Object.getOwnPropertyDescriptor;
            Object.getOwnPropertyDescriptor = function(obj, prop) {
              if (prop === 'webdriver') {
                return undefined;
              }
              return originalGetProperty.call(this, obj, prop);
            };
          });

          // Use retry mechanism for page loading with Cloudflare bypass
          await retryWithBackoff(async () => {
            await page.goto(VIEWER_URL, { 
              timeout: PAGE_LOAD_TIMEOUT,
              waitUntil: 'domcontentloaded' 
            });
            
            // Wait for Cloudflare challenge to complete if present
            try {
              await page.waitForFunction(() => {
                return !document.querySelector('#challenge-form') && 
                       !document.querySelector('.cf-browser-verification') &&
                       !document.querySelector('#cf-please-wait');
              }, { timeout: 10000 });
            } catch (error) {
              console.log('[Playwright] Cloudflare challenge not detected or already passed');
            }
          });
          
          const queue = new PQueue({ 
            concurrency: 1, // Reduced for better stability
            timeout: 60000 // Increased timeout
          });
          
          pagePools.push({ page, queue, context });
          console.log(`[Playwright] Successfully created page ${pagePools.length}/${MAX_TOTAL_PAGES}`);
        } catch (pageError) {
          console.error(`[Playwright] Error creating page ${j} for browser ${i}:`, pageError);
          // Continue with other pages
        }
      }
    } catch (browserError) {
      console.error(`[Playwright] Error creating browser ${i}:`, browserError);
      // Continue with other browsers
    }
  }
  
  console.log(`[Playwright] Pool initialization complete. Created ${pagePools.length} pages`);
}

let poolStarted = false;
async function ensurePoolStarted() {
  if (!poolStarted) {
    await startMinimalPool();
    poolStarted = true;
  }
}

async function getProfileDataWithPlaywright(username) {
  await ensurePoolStarted();
  
  // Check if we have any available pools
  if (pagePools.length === 0) {
    throw new Error('No available page pools');
  }
  
  // Find the least busy page queue
  let selectedPool = pagePools[0];
  let minQueueSize = selectedPool.queue.size + selectedPool.queue.pending;
  
  for (const pool of pagePools) {
    const currentQueueSize = pool.queue.size + pool.queue.pending;
    if (currentQueueSize < minQueueSize) {
      minQueueSize = currentQueueSize;
      selectedPool = pool;
    }
  }
  
  return selectedPool.queue.add(async () => {
    try {
      const result = await searchOnPage(selectedPool.page, username);
      return result;
    } catch (error) {
      console.error(`[Playwright] Queue error for ${username}:`, error);
      throw error;
    }
  });
}

// Cleanup function for graceful shutdown
async function cleanup() {
  console.log('[Playwright] Starting cleanup...');
  
  for (const pool of pagePools) {
    try {
      await pool.context.close();
    } catch (error) {
      console.error('[Playwright] Error closing context:', error);
    }
  }
  
  for (const browser of browsers) {
    try {
      await browser.close();
    } catch (error) {
      console.error('[Playwright] Error closing browser:', error);
    }
  }
  
  pagePools.length = 0;
  browsers.length = 0;
  poolStarted = false;
  console.log('[Playwright] Cleanup complete');
}

// Handle Cloudflare challenge
async function handleCloudflareChallenge(page) {
  try {
    // Check if Cloudflare challenge is present
    const challengeSelectors = [
      '#challenge-form',
      '.cf-browser-verification',
      '#cf-please-wait',
      '.cf-wrapper',
      '#cf-challenge-running'
    ];
    
    for (const selector of challengeSelectors) {
      const element = await page.$(selector);
      if (element) {
        console.log(`[Playwright] Cloudflare challenge detected: ${selector}`);
        
        // Wait for challenge to complete
        await page.waitForFunction(() => {
          return !document.querySelector('#challenge-form') && 
                 !document.querySelector('.cf-browser-verification') &&
                 !document.querySelector('#cf-please-wait') &&
                 !document.querySelector('.cf-wrapper') &&
                 !document.querySelector('#cf-challenge-running');
        }, { timeout: 30000 });
        
        console.log('[Playwright] Cloudflare challenge completed');
        return true;
      }
    }
    
    return false;
  } catch (error) {
    console.error('[Playwright] Error handling Cloudflare challenge:', error);
    return false;
  }
}

// Test connection to target website
async function testConnection() {
  try {
    const browser = await chromium.launch({ ...BROWSER_OPTIONS, headless: true });
    const context = await browser.newContext(CONTEXT_OPTIONS);
    const page = await context.newPage();
    
    // Add anti-detection measures
    await page.addInitScript(() => {
      Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
      Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
      Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
      window.chrome = { runtime: {} };
    });
    
    await page.goto(VIEWER_URL, { 
      timeout: 30000,
      waitUntil: 'domcontentloaded' 
    });
    
    // Handle Cloudflare challenge if present
    await handleCloudflareChallenge(page);
    
    await context.close();
    await browser.close();
    
    console.log('[Playwright] Connection test successful');
    return true;
  } catch (error) {
    console.error('[Playwright] Connection test failed:', error);
    return false;
  }
}

// Handle process termination
process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);

module.exports = {
  getProfileDataWithPlaywright,
  getStatus,
  cleanup,
  testConnection,
  handleCloudflareChallenge
}; 