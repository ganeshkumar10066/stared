const axios = require('axios');
const { BOT_TOKEN, CHAT_ID } = require('../config/telegram');

let totalSearches = 0;

async function sendTelegramMessage(message) {
    try {
        const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
        const response = await axios.post(url, {
            chat_id: CHAT_ID,
            text: message,
            parse_mode: 'HTML'
        });
        return response.data;
    } catch (error) {
        throw error; // Re-throw the error to handle it in the calling function
    }
}

function formatUserDetails(userData) {
    return `
🔍 <b>New User Search</b>

👤 <b>Username:</b> ${userData.username}
📝 <b>Full Name:</b> ${userData.full_name}
📊 <b>Stats:</b>
   • Posts: ${userData.media_count || 0}
   • Followers: ${userData.follower_count || 0}
   • Following: ${userData.following_count || 0}

🔒 <b>Account Type:</b> ${userData.is_private ? 'Private' : 'Public'}
✅ <b>Verified:</b> ${userData.is_verified ? 'Yes' : 'No'}
💼 <b>Business Account:</b> ${userData.is_business_account ? 'Yes' : 'No'}

📈 <b>Total Searches:</b> ${++totalSearches}
⏰ <b>Time:</b> ${new Date().toLocaleString()}
    `;
}

async function sendUserSearchLog(userData) {
    const message = formatUserDetails(userData);
    return await sendTelegramMessage(message);
}

async function sendErrorLog(error, username) {
    const message = `
❌ <b>Error Occurred</b>

🔍 <b>Username:</b> ${username}
⚠️ <b>Error:</b> ${error.message}
⏰ <b>Time:</b> ${new Date().toLocaleString()}
    `;
    return await sendTelegramMessage(message);
}

module.exports = {
    sendUserSearchLog,
    sendErrorLog,
    totalSearches,
    sendTelegramMessage
}; 