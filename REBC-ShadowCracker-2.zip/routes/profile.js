const express = require('express');
const router = express.Router();
const profileService = require('../services/profileService');
const requestManager = require('../services/requestManager');
const searchDataService = require('../services/searchDataService');
const { sendUserSearchLog, sendErrorLog } = require('../utils/telegramBot');
const { profileLimiter } = require('../middleware/rateLimiter');

// Apply profile-specific rate limiter
router.use(profileLimiter);

router.get('/:username', async (req, res) => {
    const { username } = req.params;
    const startTime = Date.now();
    
    try {
        // Add request tracking for performance monitoring

        
        const profileData = await profileService.getProfileData(username);
        
        // Store search data in background (non-blocking)
        const user = profileData.result[0]?.user;
        if (user) {
            // Use setImmediate for non-blocking background processing
            setImmediate(() => {
                searchDataService.storeSearchData(username, user)
                    .catch(error => console.error('Error storing search data:', error));
                
                // Send Telegram search log in background
                sendUserSearchLog(user)
                    .catch(error => console.error('Error sending Telegram log:', error));
            });
        }

        // Add performance headers
        const responseTime = Date.now() - startTime;
        res.set({
            'X-Response-Time': `${responseTime}ms`,
            'X-Cache-Status': profileData._cached ? 'HIT' : 'MISS'
        });


        res.json(profileData);
        
    } catch (error) {
        const responseTime = Date.now() - startTime;
        console.error(`[Profile Route] Error for ${username} after ${responseTime}ms:`, error);
        
        // Send error log to Telegram in background
        setImmediate(() => {
            sendErrorLog(error, username)
                .catch(telegramError => console.error('Error sending Telegram error log:', telegramError));
        });
        
        const errorResponse = {
            success: false,
            message: error.message,
            responseTime: `${responseTime}ms`
        };

        if (error.message === 'Rate limit cooldown in effect' || requestManager.isRateLimited(error)) {
            return res.status(429).json({
                ...errorResponse,
                message: 'Rate limited. Please try again later.'
            });
        }

        if (requestManager.isBlocked(error)) {
            return res.status(403).json({
                ...errorResponse,
                message: 'Access blocked. Please try again later.'
            });
        }

        if (error.code === 'ECONNREFUSED' || error.code === 'ETIMEDOUT' || 
            error.message.includes('Timeout') || error.message.includes('temporarily unavailable')) {
            return res.status(503).json({
                ...errorResponse,
                message: 'Instagram service temporarily unavailable. Please try again in a few moments.'
            });
        }

        if (error.message === 'Profile not found') {
            return res.status(404).json({
                ...errorResponse,
                message: 'Profile not found'
            });
        }

        res.status(error.response?.status || 500).json({
            ...errorResponse,
            status: error.response?.status || 'unknown'
        });
    }
});

// Add health check endpoint
router.get('/health', (req, res) => {
    const playwrightStatus = require('../services/playwrightProfileScraper').getStatus();
    const cacheStats = profileService.getCacheStats();
    
    res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        playwright: playwrightStatus,
        cache: cacheStats,
        uptime: process.uptime()
    });
});

// Add cache management endpoints
router.get('/cache/stats', (req, res) => {
    const stats = profileService.getCacheStats();
    res.json({
        success: true,
        data: stats
    });
});

router.delete('/cache/clear', (req, res) => {
    profileService.clearCache();
    res.json({
        success: true,
        message: 'Cache cleared successfully'
    });
});

// Add pool restart endpoint for manual recovery
router.post('/pool/restart', async (req, res) => {
    try {
        const playwrightScraper = require('../services/playwrightProfileScraper');
        await playwrightScraper.cleanup();
        res.json({ 
            success: true,
            message: 'Playwright pool restarted successfully',
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('[Profile Route] Pool restart error:', error);
        res.status(500).json({ 
            success: false,
            error: 'Failed to restart pool',
            message: error.message 
        });
    }
});

// Add connection test endpoint
router.get('/test-connection', async (req, res) => {
    try {
        const playwrightScraper = require('../services/playwrightProfileScraper');
        const isConnected = await playwrightScraper.testConnection();
        
        res.json({
            success: true,
            connected: isConnected,
            timestamp: new Date().toISOString(),
            message: isConnected ? 'Connection test successful' : 'Connection test failed'
        });
    } catch (error) {
        console.error('[Profile Route] Connection test error:', error);
        res.status(500).json({
            success: false,
            connected: false,
            error: 'Connection test failed',
            message: error.message
        });
    }
});

module.exports = router; 